/**
 * SOI+ - Sistema Operacional Inteligente para Construtoras
 * Componente Principal com AuthGate e Proteção de Borda
 */

import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './firebase/auth';
import { Navbar } from './components/common/Navbar';
import { OfflineBanner } from './components/common/OfflineBanner';
import { AuditTrailModal } from './components/common/AuditTrailModal';
import { SistemaDashboard } from './components/sistema/SistemaDashboard';
import { AppFieldHome } from './components/app/AppFieldHome';
import { LoginView } from './components/auth/LoginView';
import { InactiveUserView } from './components/auth/InactiveUserView';
import { PendingUserView } from './components/auth/PendingUserView';
import { FirestoreService } from './services/firestoreService';
import { testConnection } from './firebase/config';
import {
  Atividade,
  CriterioProntidao,
  Etapa,
  Execucao,
  Obra,
  Ocorrencia,
  Pendencia,
  Recurso,
  StatusAtividade,
  StatusObra,
} from './domain/types';
import { DEMO_OBRAS } from './domain/demoData';

function SOIApp() {
  const { currentUser, userProfile, isInactive, isPending, isDemoMode, loading: authLoading } = useAuth();
  const [currentEnv, setCurrentEnv] = useState<'/sistema' | '/app'>('/sistema');
  const [showAuditoriaModal, setShowAuditoriaModal] = useState(false);
  const [loadingData, setLoadingData] = useState(false);

  // Core Data States
  const [obras, setObras] = useState<Obra[]>([]);
  const [obraAtiva, setObraAtiva] = useState<Obra | null>(null);
  const [etapas, setEtapas] = useState<Etapa[]>([]);
  const [atividades, setAtividades] = useState<Atividade[]>([]);
  const [execucoes, setExecucoes] = useState<Execucao[]>([]);
  const [ocorrencias, setOcorrencias] = useState<Ocorrencia[]>([]);
  const [pendencias, setPendencias] = useState<Pendencia[]>([]);
  const [recursos, setRecursos] = useState<Recurso[]>([]);

  // Sync route with pathname if accessed via /app
  useEffect(() => {
    if (window.location.pathname.startsWith('/app')) {
      setCurrentEnv('/app');
    } else {
      setCurrentEnv('/sistema');
    }
  }, []);

  // Initial connection test and data load only when authenticated and active, or in demo mode
  const loadData = async () => {
    if ((!currentUser || isPending || isInactive) && !isDemoMode) return;
    setLoadingData(true);
    try {
      await testConnection();
      const obrasList = await FirestoreService.listarObras(userProfile);
      setObras(obrasList);
      const selectedObra = obrasList[0] || DEMO_OBRAS[0];
      setObraAtiva(selectedObra);

      if (selectedObra) {
        await loadObraDetails(selectedObra.id);
      }
    } catch (e) {
      console.warn('Erro ao carregar dados:', e);
    } finally {
      setLoadingData(false);
    }
  };

  const loadObraDetails = async (obraId: string) => {
    const [et, at, ex, oc, pe, re] = await Promise.all([
      FirestoreService.listarEtapas(obraId),
      FirestoreService.listarAtividades(obraId),
      FirestoreService.listarExecucoes(obraId),
      FirestoreService.listarOcorrencias(obraId),
      FirestoreService.listarPendencias(obraId),
      FirestoreService.listarRecursos(obraId),
    ]);
    setEtapas(et);
    setAtividades(at);
    setExecucoes(ex);
    setOcorrencias(oc);
    setPendencias(pe);
    setRecursos(re);
  };

  useEffect(() => {
    if ((currentUser && !isInactive && !isPending) || isDemoMode) {
      loadData();
    }
  }, [currentUser, isInactive, isPending, isDemoMode]);

  // ==========================================
  // AUTH GATE: BLOQUEIO ESTRITO DE NÃO AUTENTICADOS E NÃO APROVADOS
  // ==========================================
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs font-semibold">Validando credenciais do Firebase...</p>
      </div>
    );
  }

  // Usuário inativo: bloqueio imediato
  if (currentUser && isInactive) {
    return <InactiveUserView />;
  }

  // Usuário pendente: bloqueio imediato com tela de aguardo de aprovação
  if (currentUser && isPending) {
    return <PendingUserView />;
  }

  // Não autenticado e fora do modo de demonstração: exibe SOMENTE o login
  if (!currentUser && !isDemoMode) {
    return <LoginView />;
  }

  const handleChangeObra = async (novaObra: Obra) => {
    setObraAtiva(novaObra);
    await loadObraDetails(novaObra.id);
  };

  // Operational Operations with deterministic gates
  const handleSalvarObra = async (novaObra: Obra) => {
    if (!userProfile) return;
    await FirestoreService.salvarObra(novaObra, userProfile);
    setObras((prev) => [novaObra, ...prev.filter((o) => o.id !== novaObra.id)]);
    setObraAtiva(novaObra);
  };

  const handleAtualizarStatusObra = async (obra: Obra, novoStatus: StatusObra) => {
    if (!userProfile) return { sucesso: false, erro: 'Usuário não autenticado' };
    const res = await FirestoreService.atualizarStatusObra(
      obra,
      novoStatus,
      etapas,
      atividades,
      ocorrencias,
      pendencias,
      userProfile
    );
    if (res.sucesso) {
      setObras((prev) => prev.map((o) => (o.id === obra.id ? { ...o, status: novoStatus } : o)));
      if (obraAtiva?.id === obra.id) {
        setObraAtiva({ ...obraAtiva, status: novoStatus });
      }
    }
    return res;
  };

  const handleAdicionarEtapa = async (nome: string, ordem: number) => {
    if (!obraAtiva || !userProfile) return;
    const novaEtapa: Etapa = {
      id: 'etapa_' + Date.now(),
      obraId: obraAtiva.id,
      nome,
      ordem,
      status: 'planejada',
      dataInicio: new Date().toISOString().split('T')[0],
      dataPrevisaoFim: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await FirestoreService.salvarEtapa(novaEtapa, userProfile);
    setEtapas((prev) => [...prev, novaEtapa]);
  };

  const handleAdicionarAtividade = async (
    etapaId: string,
    nome: string,
    localizacao: string,
    dependencias: string[]
  ) => {
    if (!obraAtiva || !userProfile) return;
    const novaAtiv: Atividade = {
      id: 'ativ_' + Date.now(),
      obraId: obraAtiva.id,
      etapaId,
      nome,
      descricao: `Atividade de canteiro executada na etapa correspondente.`,
      ordem: atividades.length + 1,
      status: 'planejada',
      dependencias,
      prontidaoAtendida: false,
      criteriosProntidao: [
        { id: 'crit_' + Date.now() + '_1', titulo: 'Conferência de Projeto Executivo', tipo: 'projeto', obrigatorio: true, atendido: false },
        { id: 'crit_' + Date.now() + '_2', titulo: 'Disponibilidade de Insumos no Almoxarifado', tipo: 'material', obrigatorio: true, atendido: false },
        { id: 'crit_' + Date.now() + '_3', titulo: 'Inspeção de EPIs e Liberação de Segurança (NR-18)', tipo: 'seguranca', obrigatorio: true, atendido: false },
      ],
      localizacao: localizacao || 'Canteiro Geral',
      encarregadoId: userProfile.uid,
      encarregadoNome: userProfile.nome,
      dataInicioPrevista: new Date().toISOString().split('T')[0],
      dataFimPrevista: new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0],
      percentualAvanco: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await FirestoreService.salvarAtividade(novaAtiv, userProfile);
    setAtividades((prev) => [...prev, novaAtiv]);
  };

  const handleAtualizarStatusAtividade = async (ativ: Atividade, novoStatus: StatusAtividade) => {
    if (!userProfile) return { sucesso: false, erro: 'Usuário não autenticado' };
    const res = await FirestoreService.atualizarStatusAtividade(
      ativ,
      novoStatus,
      atividades,
      userProfile
    );
    if (res.sucesso) {
      setAtividades((prev) => prev.map((a) => (a.id === ativ.id ? { ...a, status: novoStatus } : a)));
    }
    return res;
  };

  const handleSalvarProntidao = async (ativ: Atividade, criterios: CriterioProntidao[]) => {
    if (!userProfile) return;
    await FirestoreService.atualizarProntidaoAtividade(ativ, criterios, userProfile);
    const todosObrigatoriosAtendidos = criterios.filter((c) => c.obrigatorio).every((c) => c.atendido);
    setAtividades((prev) =>
      prev.map((a) =>
        a.id === ativ.id
          ? { ...a, criteriosProntidao: criterios, prontidaoAtendida: todosObrigatoriosAtendidos }
          : a
      )
    );
  };

  const handleSalvarExecucao = async (exec: Execucao) => {
    if (!userProfile) return;
    await FirestoreService.registrarExecucao(exec, userProfile);
    setExecucoes((prev) => [exec, ...prev]);
    setAtividades((prev) =>
      prev.map((a) => {
        if (a.id === exec.atividadeId) {
          return {
            ...a,
            percentualAvanco: exec.percentualAvanco,
            status: exec.percentualAvanco === 100 ? 'concluida' : 'em_execucao',
          };
        }
        return a;
      })
    );
  };

  const handleSalvarOcorrencia = async (oco: Ocorrencia) => {
    if (!userProfile) return;
    await FirestoreService.salvarOcorrencia(oco, userProfile);
    setOcorrencias((prev) => [oco, ...prev.filter((o) => o.id !== oco.id)]);
  };

  const handleEncerrarOcorrencia = async (oco: Ocorrencia, resolucaoTexto: string) => {
    if (!userProfile) return { sucesso: false, erro: 'Usuário não autenticado' };
    const res = await FirestoreService.atualizarStatusOcorrencia(
      oco,
      'encerrada',
      userProfile,
      resolucaoTexto
    );
    if (res.sucesso) {
      setOcorrencias((prev) =>
        prev.map((o) =>
          o.id === oco.id
            ? {
                ...o,
                status: 'encerrada',
                resolucao: resolucaoTexto,
                autorizadoPor: `${userProfile.nome} (${userProfile.cargo})`,
                autorizadoEm: new Date().toISOString(),
              }
            : o
        )
      );
    }
    return res;
  };

  const handleSalvarPendencia = async (pend: Pendencia) => {
    if (!userProfile) return;
    await FirestoreService.salvarPendencia(pend, userProfile);
    setPendencias((prev) => [pend, ...prev.filter((p) => p.id !== pend.id)]);
  };

  const handleConcluirPendencia = async (pend: Pendencia) => {
    if (!userProfile) return;
    await FirestoreService.concluirPendencia(pend, userProfile);
    setPendencias((prev) =>
      prev.map((p) =>
        p.id === pend.id
          ? {
              ...p,
              status: 'concluida',
              concluidaPor: userProfile.nome,
              concluidaEm: new Date().toISOString(),
            }
          : p
      )
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        currentEnv={currentEnv}
        onChangeEnv={(env) => {
          setCurrentEnv(env);
          window.history.pushState({}, '', env);
        }}
        onOpenAuditoria={() => setShowAuditoriaModal(true)}
        onRefreshData={loadData}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {loadingData || !obraAtiva ? (
          <div className="flex flex-col items-center justify-center py-24 text-slate-400">
            <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-xs font-semibold">Carregando dados operacionais da construtora...</p>
          </div>
        ) : currentEnv === '/sistema' ? (
          <SistemaDashboard
            obras={obras}
            etapas={etapas}
            atividades={atividades}
            execucoes={execucoes}
            ocorrencias={ocorrencias}
            pendencias={pendencias}
            recursos={recursos}
            obraAtiva={obraAtiva}
            onSelectObra={handleChangeObra}
            onSalvarObra={handleSalvarObra}
            onAtualizarStatusObra={handleAtualizarStatusObra}
            onAdicionarEtapa={handleAdicionarEtapa}
            onAdicionarAtividade={handleAdicionarAtividade}
            onAtualizarStatusAtividade={handleAtualizarStatusAtividade}
            onSalvarProntidao={handleSalvarProntidao}
            onSalvarOcorrencia={handleSalvarOcorrencia}
            onEncerrarOcorrencia={handleEncerrarOcorrencia}
            onSalvarPendencia={handleSalvarPendencia}
            onConcluirPendencia={handleConcluirPendencia}
          />
        ) : (
          <AppFieldHome
            obra={obraAtiva}
            obras={obras}
            atividades={atividades}
            execucoes={execucoes}
            ocorrencias={ocorrencias}
            onSelectObra={handleChangeObra}
            onSalvarExecucao={handleSalvarExecucao}
            onSalvarProntidao={handleSalvarProntidao}
            onSalvarOcorrencia={handleSalvarOcorrencia}
            onAtualizarStatusAtividade={handleAtualizarStatusAtividade}
          />
        )}
      </main>

      {/* Offline Status & Sync Banner */}
      <OfflineBanner />

      {/* Audit Trail Modal */}
      <AuditTrailModal
        isOpen={showAuditoriaModal}
        onClose={() => setShowAuditoriaModal(false)}
        entidadeId={obraAtiva?.id}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SOIApp />
    </AuthProvider>
  );
}
