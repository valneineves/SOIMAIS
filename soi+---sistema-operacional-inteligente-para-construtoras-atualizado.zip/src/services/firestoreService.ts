/**
 * SOI+ - Serviço de Integração com Cloud Firestore, Auditoria e Reconciliação
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  limit,
} from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/errors';
import {
  Atividade,
  Etapa,
  Execucao,
  Obra,
  Ocorrencia,
  Pendencia,
  Recurso,
  RegistroAuditoria,
  StatusAtividade,
  StatusObra,
  StatusOcorrencia,
  UserProfile,
} from '../domain/types';
import {
  validarTransicaoAtividade,
  validarTransicaoObra,
  validarTransicaoOcorrencia,
} from '../domain/rules';
import { OfflineStorageService } from './offlineStorage';
import {
  DEMO_ATIVIDADES,
  DEMO_ETAPAS,
  DEMO_EXECUCOES,
  DEMO_OBRAS,
  DEMO_OCORRENCIAS,
  DEMO_PENDENCIAS,
  DEMO_RECURSOS,
} from '../domain/demoData';

export const FirestoreService = {
  // ==========================================
  // VALIDAÇÃO DE SEGURANÇA INTERNA
  // ==========================================
  assertActiveUser(usuario: UserProfile): void {
    if (usuario.status === 'inativo') {
      throw new Error('Operação bloqueada: Usuário inativo não possui permissão no sistema.');
    }
  },

  // ==========================================
  // AUDITORIA (Imutável)
  // ==========================================
  async registrarAuditoria(
    entidade: RegistroAuditoria['entidade'],
    entidadeId: string,
    acao: string,
    de: string,
    para: string,
    usuario: UserProfile,
    detalhes: string
  ): Promise<void> {
    this.assertActiveUser(usuario);
    const id = 'aud_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const registro: RegistroAuditoria = {
      id,
      entidade,
      entidadeId,
      acao,
      de,
      para,
      usuarioUid: usuario.uid,
      usuarioNome: usuario.nome,
      detalhes,
      timestamp: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'auditoria', id), registro);
    } catch (e) {
      console.warn('Auditoria salva localmente (offline):', e);
      OfflineStorageService.adicionarAFila('atividade_status', { tipo: 'auditoria', registro });
    }
  },

  async listarAuditoria(entidadeId?: string): Promise<RegistroAuditoria[]> {
    try {
      const colRef = collection(db, 'auditoria');
      const q = entidadeId
        ? query(colRef, where('entidadeId', '==', entidadeId), limit(50))
        : query(colRef, limit(50));
      const snap = await getDocs(q);
      const res: RegistroAuditoria[] = [];
      snap.forEach((d) => res.push(d.data() as RegistroAuditoria));
      return res.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    } catch (error) {
      console.warn('Erro ao carregar auditoria remota:', error);
      return [];
    }
  },

  // ==========================================
  // OBRAS
  // ==========================================
  async listarObras(usuario?: UserProfile | null): Promise<Obra[]> {
    try {
      const snap = await getDocs(collection(db, 'obras'));
      if (snap.empty) {
        OfflineStorageService.salvarCache('obras', DEMO_OBRAS);
        return DEMO_OBRAS;
      }
      const obras: Obra[] = [];
      snap.forEach((d) => obras.push(d.data() as Obra));

      // Filtro relacional: se o usuário for responsável de obra ou campo, exibe prioritariamente obras alocadas
      let obrasFiltradas = obras;
      if (usuario && usuario.role === 'responsavel_obra') {
        const alocadas = obras.filter((o) => o.responsavelUid === usuario.uid);
        if (alocadas.length > 0) obrasFiltradas = alocadas;
      }

      OfflineStorageService.salvarCache('obras', obrasFiltradas);
      return obrasFiltradas;
    } catch (error) {
      console.warn('Fallback para cache de obras:', error);
      const cache = OfflineStorageService.obterCache<Obra[]>('obras');
      return cache || DEMO_OBRAS;
    }
  },

  async salvarObra(obra: Obra, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    if (usuario.role !== 'gestao' && usuario.role !== 'administracao') {
      throw new Error('Apenas Gestão ou Administração podem cadastrar ou alterar dados estruturais da Obra.');
    }

    try {
      await setDoc(doc(db, 'obras', obra.id), obra);
      await this.registrarAuditoria(
        'obra',
        obra.id,
        'Criação/Atualização de Obra',
        '-',
        obra.status,
        usuario,
        `Obra "${obra.nome}" (${obra.codigo}) atualizada por ${usuario.nome}`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `obras/${obra.id}`);
    }
  },

  async atualizarStatusObra(
    obra: Obra,
    novoStatus: StatusObra,
    etapas: Etapa[],
    atividades: Atividade[],
    ocorrencias: Ocorrencia[],
    pendencias: Pendencia[],
    usuario: UserProfile
  ): Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }> {
    this.assertActiveUser(usuario);

    const validacao = validarTransicaoObra(
      obra,
      novoStatus,
      etapas,
      atividades,
      ocorrencias,
      pendencias,
      usuario.role
    );

    if (!validacao.valido) {
      return { sucesso: false, erro: validacao.motivo, bloqueios: validacao.bloqueios };
    }

    try {
      await updateDoc(doc(db, 'obras', obra.id), {
        status: novoStatus,
        updatedAt: new Date().toISOString(),
      });

      await this.registrarAuditoria(
        'obra',
        obra.id,
        'Transição de Status de Obra',
        obra.status,
        novoStatus,
        usuario,
        `Status da obra "${obra.nome}" alterado para "${novoStatus}" por ${usuario.nome}`
      );

      return { sucesso: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `obras/${obra.id}`);
    }
  },

  // ==========================================
  // ETAPAS
  // ==========================================
  async listarEtapas(obraId: string): Promise<Etapa[]> {
    try {
      const q = query(collection(db, 'etapas'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_ETAPAS.filter((e) => e.obraId === obraId || e.obraId === 'obra_demo_01');
      }
      const etapas: Etapa[] = [];
      snap.forEach((d) => etapas.push(d.data() as Etapa));
      return etapas.sort((a, b) => a.ordem - b.ordem);
    } catch {
      return DEMO_ETAPAS.filter((e) => e.obraId === obraId || e.obraId === 'obra_demo_01');
    }
  },

  async salvarEtapa(etapa: Etapa, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    try {
      await setDoc(doc(db, 'etapas', etapa.id), etapa);
      await this.registrarAuditoria(
        'etapa',
        etapa.id,
        'Cadastro de Etapa',
        '-',
        etapa.status,
        usuario,
        `Etapa "${etapa.nome}" registrada`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `etapas/${etapa.id}`);
    }
  },

  // ==========================================
  // ATIVIDADES & PRONTIDÃO
  // ==========================================
  async listarAtividades(obraId: string): Promise<Atividade[]> {
    try {
      const q = query(collection(db, 'atividades'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_ATIVIDADES.filter((a) => a.obraId === obraId || a.obraId === 'obra_demo_01');
      }
      const ativs: Atividade[] = [];
      snap.forEach((d) => ativs.push(d.data() as Atividade));
      OfflineStorageService.salvarCache(`atividades_${obraId}`, ativs);
      return ativs.sort((a, b) => a.ordem - b.ordem);
    } catch {
      const cache = OfflineStorageService.obterCache<Atividade[]>(`atividades_${obraId}`);
      return cache || DEMO_ATIVIDADES.filter((a) => a.obraId === obraId || a.obraId === 'obra_demo_01');
    }
  },

  async salvarAtividade(atividade: Atividade, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    try {
      await setDoc(doc(db, 'atividades', atividade.id), atividade);
      await this.registrarAuditoria(
        'atividade',
        atividade.id,
        'Criação/Atualização de Atividade',
        '-',
        atividade.status,
        usuario,
        `Atividade "${atividade.nome}" cadastrada`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `atividades/${atividade.id}`);
    }
  },

  async atualizarStatusAtividade(
    atividade: Atividade,
    novoStatus: StatusAtividade,
    todasAtividades: Atividade[],
    usuario: UserProfile
  ): Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }> {
    this.assertActiveUser(usuario);

    const validacao = validarTransicaoAtividade(atividade, novoStatus, todasAtividades, usuario.role);
    if (!validacao.valido) {
      return { sucesso: false, erro: validacao.motivo, bloqueios: validacao.bloqueios };
    }

    try {
      await updateDoc(doc(db, 'atividades', atividade.id), {
        status: novoStatus,
        updatedAt: new Date().toISOString(),
      });

      await this.registrarAuditoria(
        'atividade',
        atividade.id,
        'Transição de Status',
        atividade.status,
        novoStatus,
        usuario,
        `Atividade "${atividade.nome}" avançou para "${novoStatus}"`
      );

      return { sucesso: true };
    } catch (error) {
      // Se estiver sem conexão no canteiro, enfileira com o timestamp local conhecido
      OfflineStorageService.adicionarAFila('atividade_status', {
        atividadeId: atividade.id,
        novoStatus,
        anterior: atividade.status,
        usuarioUid: usuario.uid,
      }, atividade.updatedAt);
      return { sucesso: true };
    }
  },

  async atualizarProntidaoAtividade(
    atividade: Atividade,
    criteriosAtualizados: Atividade['criteriosProntidao'],
    usuario: UserProfile
  ): Promise<void> {
    this.assertActiveUser(usuario);
    const todosObrigatoriosAtendidos = criteriosAtualizados
      .filter((c) => c.obrigatorio)
      .every((c) => c.atendido);

    try {
      await updateDoc(doc(db, 'atividades', atividade.id), {
        criteriosProntidao: criteriosAtualizados,
        prontidaoAtendida: todosObrigatoriosAtendidos,
        updatedAt: new Date().toISOString(),
      });

      await this.registrarAuditoria(
        'prontidao',
        atividade.id,
        'Checklist de Prontidão',
        atividade.prontidaoAtendida ? 'atendida' : 'incompleta',
        todosObrigatoriosAtendidos ? 'atendida' : 'incompleta',
        usuario,
        `Critérios atualizados por ${usuario.nome}. Apto para liberação: ${todosObrigatoriosAtendidos}`
      );
    } catch {
      OfflineStorageService.adicionarAFila('prontidao_check', {
        atividadeId: atividade.id,
        criterios: criteriosAtualizados,
        usuarioUid: usuario.uid,
      }, atividade.updatedAt);
    }
  },

  // ==========================================
  // EXECUÇÕES (Apontamentos de Campo)
  // ==========================================
  async listarExecucoes(obraId: string): Promise<Execucao[]> {
    try {
      const q = query(collection(db, 'execucoes'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_EXECUCOES.filter((e) => e.obraId === obraId || e.obraId === 'obra_demo_01');
      }
      const execs: Execucao[] = [];
      snap.forEach((d) => execs.push(d.data() as Execucao));
      return execs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch {
      return DEMO_EXECUCOES.filter((e) => e.obraId === obraId || e.obraId === 'obra_demo_01');
    }
  },

  async registrarExecucao(execucao: Execucao, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);

    // Se offline, enfileira de forma idempotente com o ID já definido
    if (!navigator.onLine) {
      OfflineStorageService.adicionarAFila('execucao', execucao, execucao.updatedAt);
      return;
    }

    try {
      await setDoc(doc(db, 'execucoes', execucao.id), execucao);
      if (execucao.percentualAvanco === 100) {
        await updateDoc(doc(db, 'atividades', execucao.atividadeId), {
          status: 'concluida',
          percentualAvanco: 100,
          updatedAt: new Date().toISOString(),
        });
      } else if (execucao.percentualAvanco > 0) {
        await updateDoc(doc(db, 'atividades', execucao.atividadeId), {
          percentualAvanco: execucao.percentualAvanco,
          status: 'em_execucao',
          updatedAt: new Date().toISOString(),
        });
      }

      await this.registrarAuditoria(
        'execucao',
        execucao.id,
        `Apontamento de Campo (${execucao.tipo})`,
        '-',
        `${execucao.percentualAvanco}%`,
        usuario,
        `Efetivo: ${execucao.efetivoPresente} operários. Clima: ${execucao.clima}. Obs: ${execucao.observacao}`
      );
    } catch {
      OfflineStorageService.adicionarAFila('execucao', execucao, execucao.updatedAt);
    }
  },

  // ==========================================
  // OCORRÊNCIAS
  // ==========================================
  async listarOcorrencias(obraId: string): Promise<Ocorrencia[]> {
    try {
      const q = query(collection(db, 'ocorrencias'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_OCORRENCIAS.filter((o) => o.obraId === obraId || o.obraId === 'obra_demo_01');
      }
      const ocos: Ocorrencia[] = [];
      snap.forEach((d) => ocos.push(d.data() as Ocorrencia));
      return ocos.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch {
      return DEMO_OCORRENCIAS.filter((o) => o.obraId === obraId || o.obraId === 'obra_demo_01');
    }
  },

  async salvarOcorrencia(ocorrencia: Ocorrencia, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);

    if (!navigator.onLine) {
      OfflineStorageService.adicionarAFila('ocorrencia', ocorrencia, ocorrencia.updatedAt);
      return;
    }

    try {
      await setDoc(doc(db, 'ocorrencias', ocorrencia.id), ocorrencia);
      await this.registrarAuditoria(
        'ocorrencia',
        ocorrencia.id,
        'Registro de Ocorrência',
        '-',
        ocorrencia.gravidade,
        usuario,
        `Ocorrência ${ocorrencia.codigo} aberta: "${ocorrencia.titulo}" (${ocorrencia.tipo})`
      );
    } catch {
      OfflineStorageService.adicionarAFila('ocorrencia', ocorrencia, ocorrencia.updatedAt);
    }
  },

  async atualizarStatusOcorrencia(
    ocorrencia: Ocorrencia,
    novoStatus: StatusOcorrencia,
    usuario: UserProfile,
    resolucaoTexto?: string
  ): Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }> {
    this.assertActiveUser(usuario);

    const validacao = validarTransicaoOcorrencia(ocorrencia, novoStatus, usuario.role, resolucaoTexto);
    if (!validacao.valido) {
      return { sucesso: false, erro: validacao.motivo, bloqueios: validacao.bloqueios };
    }

    try {
      const updatePayload: Partial<Ocorrencia> = {
        status: novoStatus,
        updatedAt: new Date().toISOString(),
      };

      if (novoStatus === 'encerrada') {
        updatePayload.resolucao = resolucaoTexto || ocorrencia.resolucao;
        updatePayload.autorizadoPor = `${usuario.nome} (${usuario.cargo})`;
        updatePayload.autorizadoEm = new Date().toISOString();
      }

      await updateDoc(doc(db, 'ocorrencias', ocorrencia.id), updatePayload as any);

      await this.registrarAuditoria(
        'ocorrencia',
        ocorrencia.id,
        'Encerramento de Ocorrência',
        ocorrencia.status,
        novoStatus,
        usuario,
        `Ocorrência ${ocorrencia.codigo} encerrada formalmente por ${usuario.nome}`
      );

      return { sucesso: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `ocorrencias/${ocorrencia.id}`);
    }
  },

  // ==========================================
  // PENDÊNCIAS
  // ==========================================
  async listarPendencias(obraId: string): Promise<Pendencia[]> {
    try {
      const q = query(collection(db, 'pendencias'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_PENDENCIAS.filter((p) => p.obraId === obraId || p.obraId === 'obra_demo_01');
      }
      const pends: Pendencia[] = [];
      snap.forEach((d) => pends.push(d.data() as Pendencia));
      return pends;
    } catch {
      return DEMO_PENDENCIAS.filter((p) => p.obraId === obraId || p.obraId === 'obra_demo_01');
    }
  },

  async salvarPendencia(pendencia: Pendencia, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    try {
      await setDoc(doc(db, 'pendencias', pendencia.id), pendencia);
      await this.registrarAuditoria(
        'pendencia',
        pendencia.id,
        'Cadastro de Pendência',
        '-',
        pendencia.status,
        usuario,
        `Pendência "${pendencia.titulo}" cadastrada`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `pendencias/${pendencia.id}`);
    }
  },

  async concluirPendencia(pendencia: Pendencia, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    try {
      await updateDoc(doc(db, 'pendencias', pendencia.id), {
        status: 'concluida',
        concluidaPor: usuario.nome,
        concluidaEm: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      await this.registrarAuditoria(
        'pendencia',
        pendencia.id,
        'Conclusão de Pendência',
        pendencia.status,
        'concluida',
        usuario,
        `Pendência "${pendencia.titulo}" concluída por ${usuario.nome}`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `pendencias/${pendencia.id}`);
    }
  },

  // ==========================================
  // RECURSOS
  // ==========================================
  async listarRecursos(obraId: string): Promise<Recurso[]> {
    try {
      const q = query(collection(db, 'recursos'), where('obraId', '==', obraId));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEMO_RECURSOS.filter((r) => r.obraId === obraId || r.obraId === 'obra_demo_01');
      }
      const recs: Recurso[] = [];
      snap.forEach((d) => recs.push(d.data() as Recurso));
      return recs;
    } catch {
      return DEMO_RECURSOS.filter((r) => r.obraId === obraId || r.obraId === 'obra_demo_01');
    }
  },

  async salvarRecurso(recurso: Recurso, usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    try {
      await setDoc(doc(db, 'recursos', recurso.id), recurso);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `recursos/${recurso.id}`);
    }
  },

  // ==========================================
  // USUÁRIOS E APROVAÇÃO OPERACIONAL (7.1)
  // ==========================================
  async listarUsuarios(usuario: UserProfile): Promise<UserProfile[]> {
    this.assertActiveUser(usuario);
    if (usuario.role !== 'gestao' && usuario.role !== 'administracao') {
      return [];
    }
    try {
      const snap = await getDocs(collection(db, 'users'));
      const list: UserProfile[] = [];
      snap.forEach((d) => list.push(d.data() as UserProfile));
      return list;
    } catch (error) {
      console.warn('Erro ao listar usuários no Firestore:', error);
      return [];
    }
  },

  async atualizarStatusUsuario(
    targetUser: UserProfile,
    novoStatus: 'ativo' | 'inativo' | 'pendente',
    usuarioLogado: UserProfile
  ): Promise<void> {
    this.assertActiveUser(usuarioLogado);
    if (usuarioLogado.role !== 'gestao' && usuarioLogado.role !== 'administracao') {
      throw new Error('Apenas usuários de Gestão ou Administração podem alterar o status de colaboradores.');
    }
    try {
      await updateDoc(doc(db, 'users', targetUser.uid), {
        status: novoStatus,
        updatedAt: new Date().toISOString(),
      });
      await this.registrarAuditoria(
        'usuario',
        targetUser.uid,
        `Alteração de Status para ${novoStatus.toUpperCase()}`,
        targetUser.status,
        novoStatus,
        usuarioLogado,
        `Status do colaborador "${targetUser.nome}" (${targetUser.email}) alterado para "${novoStatus}" por ${usuarioLogado.nome}`
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${targetUser.uid}`);
    }
  },

  // ==========================================
  // RECONCILIAÇÃO DETERMINÍSTICA E ANTI-CONFLITO
  // ==========================================
  async sincronizarFilaOffline(usuario: UserProfile): Promise<{
    sincronizados: number;
    conflitos: number;
    falhas: number;
  }> {
    this.assertActiveUser(usuario);
    const fila = OfflineStorageService.getFila();
    const pendentes = fila.filter((item) => item.status === 'pendente');
    if (pendentes.length === 0) return { sincronizados: 0, conflitos: 0, falhas: 0 };

    let sincronizados = 0;
    let conflitos = 0;
    let falhas = 0;

    for (const item of pendentes) {
      try {
        if (item.tipo === 'execucao') {
          // Idempotência: setDoc com o ID fixo já atribuído
          await setDoc(doc(db, 'execucoes', item.dados.id), item.dados);
          // REMOÇÃO DA FILA SOMENTE APÓS CONFIRMAÇÃO DO SERVIDOR
          OfflineStorageService.removerDaFila(item.id);
          sincronizados++;
        } else if (item.tipo === 'ocorrencia') {
          await setDoc(doc(db, 'ocorrencias', item.dados.id), item.dados);
          OfflineStorageService.removerDaFila(item.id);
          sincronizados++;
        } else if (item.tipo === 'atividade_status' || item.tipo === 'prontidao_check') {
          const ativId = item.dados.atividadeId;
          const remoteSnap = await getDoc(doc(db, 'atividades', ativId));

          if (remoteSnap.exists()) {
            const remoteData = remoteSnap.data();
            // DETECÇÃO DE CONFLITO: se o documento no servidor foi modificado após o snapshot local
            if (
              remoteData.updatedAt &&
              item.versaoRemotaTimestamp &&
              new Date(remoteData.updatedAt).getTime() > new Date(item.versaoRemotaTimestamp).getTime()
            ) {
              // Conflito detectado! NÃO sobrescreve silenciosamente
              OfflineStorageService.marcarConflito(
                item.id,
                remoteData,
                `A atividade foi alterada no servidor em ${new Date(remoteData.updatedAt).toLocaleTimeString('pt-BR')} enquanto o dispositivo estava offline.`
              );
              conflitos++;
              continue; // Preserva o dado local e pula remoção da fila
            }
          }

          // Se sem conflito, aplica a alteração
          if (item.tipo === 'prontidao_check') {
            await updateDoc(doc(db, 'atividades', ativId), {
              criteriosProntidao: item.dados.criterios,
              updatedAt: new Date().toISOString(),
            });
          } else {
            await updateDoc(doc(db, 'atividades', ativId), {
              status: item.dados.novoStatus,
              updatedAt: new Date().toISOString(),
            });
          }

          // REMOÇÃO DA FILA SOMENTE APÓS CONFIRMAÇÃO
          OfflineStorageService.removerDaFila(item.id);
          sincronizados++;
        }
      } catch (e) {
        falhas++;
        OfflineStorageService.marcarErroTentativa(item.id, e instanceof Error ? e.message : 'Falha ao sincronizar');
      }
    }

    if (sincronizados > 0) {
      await this.registrarAuditoria(
        'execucao',
        'offline_sync',
        'Sincronização Offline Concluída',
        'offline',
        'online',
        usuario,
        `${sincronizados} item(ns) sincronizado(s) com sucesso. Conflitos detectados: ${conflitos}`
      );
    }

    return { sincronizados, conflitos, falhas };
  },

  // ==========================================
  // INICIALIZAÇÃO DE DADOS DE DEMONSTRAÇÃO
  // ==========================================
  async seedDadosDemonstracao(usuario: UserProfile): Promise<void> {
    this.assertActiveUser(usuario);
    for (const obra of DEMO_OBRAS) {
      await setDoc(doc(db, 'obras', obra.id), obra);
    }
    for (const etapa of DEMO_ETAPAS) {
      await setDoc(doc(db, 'etapas', etapa.id), etapa);
    }
    for (const ativ of DEMO_ATIVIDADES) {
      await setDoc(doc(db, 'atividades', ativ.id), ativ);
    }
    for (const oco of DEMO_OCORRENCIAS) {
      await setDoc(doc(db, 'ocorrencias', oco.id), oco);
    }
    for (const pend of DEMO_PENDENCIAS) {
      await setDoc(doc(db, 'pendencias', pend.id), pend);
    }
    for (const rec of DEMO_RECURSOS) {
      await setDoc(doc(db, 'recursos', rec.id), rec);
    }
    for (const ex of DEMO_EXECUCOES) {
      await setDoc(doc(db, 'execucoes', ex.id), ex);
    }

    await this.registrarAuditoria(
      'obra',
      'seed_demo',
      'Carga de Dados de Demonstração',
      '-',
      'carregado',
      usuario,
      'Base inicial carregada com dados de teste identificados para validação operacional do SOI+'
    );
  },
};
