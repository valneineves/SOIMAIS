/**
 * SOI+ - Gerenciador de Armazenamento Offline, Fila Idempotente e Detecção de Conflitos
 * 
 * Regras Estritas:
 * 1. Cada operação possui um ID determinístico único (idempotência).
 * 2. Guarda o último timestamp conhecido do servidor (versaoRemotaTimestamp).
 * 3. Se houver divergência entre o dado local e o servidor, NÃO sobrescreve silenciosamente.
 *    Marca como 'conflito', preserva o dado local e registra para intervenção do responsável.
 * 4. A remoção da fila ocorre EXCLUSIVAMENTE após a confirmação positiva de escrita pelo servidor.
 */

export interface ConflitoSincronizacao {
  versaoServidor: any;
  mensagem: string;
  detectadoEm: string;
}

export interface ItemFilaSincronizacao {
  id: string;
  tipo: 'execucao' | 'ocorrencia' | 'prontidao_check' | 'atividade_status' | 'pendencia';
  dados: any;
  versaoRemotaTimestamp?: string;
  status: 'pendente' | 'conflito' | 'sincronizado';
  conflitoDetalhes?: ConflitoSincronizacao;
  criadoEm: string;
  tentativas: number;
  erroUltimaTentativa?: string;
}

const STORAGE_QUEUE_KEY = 'soi_offline_sync_queue_v2';
const STORAGE_OFFLINE_CACHE_KEY = 'soi_offline_cache_v2';

export const OfflineStorageService = {
  // Obter itens da fila
  getFila(): ItemFilaSincronizacao[] {
    try {
      const data = localStorage.getItem(STORAGE_QUEUE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  // Obter apenas conflitos pendentes de resolução
  obterConflitos(): ItemFilaSincronizacao[] {
    return this.getFila().filter((item) => item.status === 'conflito');
  },

  // Adicionar item à fila com snapshot de versão remota
  adicionarAFila(
    tipo: ItemFilaSincronizacao['tipo'],
    dados: any,
    versaoRemotaTimestamp?: string
  ): ItemFilaSincronizacao {
    const fila = this.getFila();
    // Idempotência garantida: se o dado já possuir um ID fixo, reutiliza para não criar duplicidade
    const id = dados.id ? `queue_${dados.id}` : `queue_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    // Evita duplicatas idênticas já na fila
    const itemExistente = fila.find((it) => it.id === id || (it.dados?.id && it.dados.id === dados.id));
    if (itemExistente) {
      itemExistente.dados = dados;
      itemExistente.versaoRemotaTimestamp = versaoRemotaTimestamp || itemExistente.versaoRemotaTimestamp;
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(fila));
      return itemExistente;
    }

    const novoItem: ItemFilaSincronizacao = {
      id,
      tipo,
      dados,
      versaoRemotaTimestamp: versaoRemotaTimestamp || dados.updatedAt,
      status: 'pendente',
      criadoEm: new Date().toISOString(),
      tentativas: 0,
    };

    fila.push(novoItem);
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(fila));
    } catch (e) {
      console.error('Falha ao gravar item na fila offline:', e);
    }
    return novoItem;
  },

  // Marca uma operação como em conflito
  marcarConflito(id: string, versaoServidor: any, mensagem: string): void {
    const fila = this.getFila().map((item) => {
      if (item.id === id) {
        return {
          ...item,
          status: 'conflito' as const,
          conflitoDetalhes: {
            versaoServidor,
            mensagem,
            detectadoEm: new Date().toISOString(),
          },
        };
      }
      return item;
    });
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(fila));
    } catch (e) {
      console.error(e);
    }
  },

  // Resolução manual de conflito
  resolverConflito(id: string, acao: 'descartar_local' | 'forcar_local'): void {
    const fila = this.getFila();
    if (acao === 'descartar_local') {
      // Remove da fila preservando a versão do servidor
      this.removerDaFila(id);
    } else {
      // Forçar: rebaixa status para 'pendente' ignorando a versão anterior
      const atualizada = fila.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            status: 'pendente' as const,
            versaoRemotaTimestamp: undefined, // remove para forçar na próxima tentativa
            conflitoDetalhes: undefined,
          };
        }
        return item;
      });
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(atualizada));
    }
  },

  // Remoção estrita após confirmação positiva do servidor
  removerDaFila(id: string): void {
    const fila = this.getFila().filter((item) => item.id !== id);
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(fila));
    } catch (e) {
      console.error('Falha ao remover item confirmado da fila:', e);
    }
  },

  // Registrar falha transitória de envio
  marcarErroTentativa(id: string, erro: string): void {
    const fila = this.getFila().map((item) => {
      if (item.id === id) {
        return {
          ...item,
          tentativas: item.tentativas + 1,
          erroUltimaTentativa: erro,
        };
      }
      return item;
    });
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(fila));
    } catch (e) {
      console.error(e);
    }
  },

  limparFila(): void {
    localStorage.removeItem(STORAGE_QUEUE_KEY);
  },

  // Cache offline
  salvarCache(chave: string, valor: any): void {
    try {
      const cacheCompleto = this.obterTodosCaches();
      cacheCompleto[chave] = {
        valor,
        atualizadoEm: new Date().toISOString(),
      };
      localStorage.setItem(STORAGE_OFFLINE_CACHE_KEY, JSON.stringify(cacheCompleto));
    } catch (e) {
      console.warn('Falha ao salvar no cache local:', e);
    }
  },

  obterCache<T>(chave: string): T | null {
    try {
      const caches = this.obterTodosCaches();
      return caches[chave]?.valor || null;
    } catch {
      return null;
    }
  },

  obterTodosCaches(): Record<string, { valor: any; atualizadoEm: string }> {
    try {
      const raw = localStorage.getItem(STORAGE_OFFLINE_CACHE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  },
};
