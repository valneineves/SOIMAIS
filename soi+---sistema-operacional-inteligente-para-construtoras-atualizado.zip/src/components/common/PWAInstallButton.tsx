import React, { useState } from 'react';
import { Download, CheckCircle, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return (
      <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 rounded-lg">
        <CheckCircle className="w-3.5 h-3.5" />
        <span>PWA Instalado</span>
      </div>
    );
  }

  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 px-3 py-1.5 text-xs font-semibold shadow-sm transition active:scale-95"
        title="Instalar aplicativo PWA de canteiro de obras"
      >
        <Download className="w-4 h-4" />
        <span>Instalar SOI+ App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-300 hover:bg-slate-800"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Instalar no iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-xl bg-slate-900 border border-slate-800 p-6 shadow-2xl text-slate-100">
              <h3 className="text-base font-bold text-amber-400 flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Instalar no iPhone / iPad
              </h3>
              <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                1. Toque no botão <strong>Compartilhar</strong> (ícone de quadrado com seta) na barra do Safari.<br /><br />
                2. Role para baixo e toque em <strong>"Adicionar à Tela de Início"</strong>.<br /><br />
                3. O ícone do SOI+ será fixado na sua tela inicial para uso no canteiro.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-lg bg-amber-500 py-2 text-sm font-bold text-slate-950 hover:bg-amber-400"
              >
                Entendi
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
