import React, { useEffect, useState } from 'react';
import { X, History, ShieldCheck, Clock, User, ArrowRight } from 'lucide-react';
import { RegistroAuditoria } from '../../domain/types';
import { FirestoreService } from '../../services/firestoreService';

interface AuditTrailModalProps {
  isOpen: boolean;
  onClose: () => void;
  entidadeId?: string;
}

export const AuditTrailModal: React.FC<AuditTrailModalProps> = ({
  isOpen,
  onClose,
  entidadeId,
}) => {
  const [registros, setRegistros] = useState<RegistroAuditoria[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      FirestoreService.listarAuditoria(entidadeId)
        .then((res) => setRegistros(res))
        .finally(() => setLoading(false));
    }
  }, [isOpen, entidadeId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
      <div className="w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col max-h-[85vh] text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-500/20 text-sky-400">
              <History className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">Trilha de Auditoria Imutável</h3>
                <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  <ShieldCheck className="w-3 h-3" />
                  Imutável
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Registro criptografado e sequencial de decisões, validações de regras e transições de status.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {loading ? (
            <div className="text-center py-12 text-slate-400">
              <Clock className="w-8 h-8 animate-spin mx-auto mb-2 text-amber-500" />
              Carregando registros de auditoria...
            </div>
          ) : registros.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              Nenhum registro de auditoria gravado ainda.
            </div>
          ) : (
            registros.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-amber-400 text-[10px] border border-slate-700">
                      {item.entidade}
                    </span>
                    <span className="font-semibold text-slate-200">{item.acao}</span>
                  </div>
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(item.timestamp).toLocaleString('pt-BR')}
                  </span>
                </div>

                <div className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/60">
                  {item.detalhes}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>Responsável: <strong className="text-slate-300">{item.usuarioNome}</strong></span>
                  </div>

                  {item.de !== '-' && (
                    <div className="flex items-center gap-1.5 font-mono text-[10px] bg-slate-800/70 px-2 py-0.5 rounded">
                      <span className="text-slate-400">{item.de}</span>
                      <ArrowRight className="w-3 h-3 text-slate-500" />
                      <span className="text-emerald-400 font-bold">{item.para}</span>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 bg-slate-950/50">
          <span>Proteção contra adulteração: Regras Firestore bloqueiam Update e Delete.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-medium transition"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
