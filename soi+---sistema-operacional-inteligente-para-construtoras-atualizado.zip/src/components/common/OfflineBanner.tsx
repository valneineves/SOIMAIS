import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff, RefreshCw, AlertCircle, AlertOctagon, CheckCircle2, ChevronRight } from 'lucide-react';
import { OfflineStorageService, ItemFilaSincronizacao } from '../../services/offlineStorage';
import { FirestoreService } from '../../services/firestoreService';
import { useAuth } from '../../firebase/auth';

export const OfflineBanner: React.FC = () => {
  const { userProfile } = useAuth();
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [fila, setFila] = useState<ItemFilaSincronizacao[]>([]);
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState<string | null>(null);
  const [conflitos, setConflitos] = useState<ItemFilaSincronizacao[]>([]);
  const [showConflictModal, setShowConflictModal] = useState(false);

  const atualizarFila = () => {
    const itens = OfflineStorageService.getFila();
    setFila(itens);
    setConflitos(itens.filter((i) => i.status === 'conflito'));
  };

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      atualizarFila();
    };
    const handleOffline = () => {
      setIsOnline(false);
      atualizarFila();
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    const interval = setInterval(atualizarFila, 3000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  const handleSync = async () => {
    if (!userProfile) return;
    setSyncing(true);
    setSyncMsg(null);
    try {
      const res = await FirestoreService.sincronizarFilaOffline(userProfile);
      atualizarFila();
      if (res.conflitos > 0) {
        setSyncMsg(`${res.sincronizados} sincronizado(s). ${res.conflitos} conflito(s) retido(s)!`);
      } else if (res.falhas === 0) {
        setSyncMsg(`${res.sincronizados} operação(ões) confirmada(s) pelo servidor!`);
      } else {
        setSyncMsg(`${res.sincronizados} confirmados, ${res.falhas} falha(s).`);
      }
      setTimeout(() => setSyncMsg(null), 4000);
    } catch (e: any) {
      setSyncMsg(e.message || 'Falha ao sincronizar com Firestore.');
    } finally {
      setSyncing(false);
    }
  };

  if (isOnline && fila.length === 0 && conflitos.length === 0 && !syncMsg) {
    return null;
  }

  const pendentesCount = fila.filter((i) => i.status === 'pendente').length;

  return (
    <>
      <div
        className={`fixed bottom-4 left-4 right-4 md:left-auto md:right-6 md:w-96 z-50 rounded-xl p-3 shadow-2xl border transition-all ${
          conflitos.length > 0
            ? 'bg-rose-950/95 border-rose-500 text-rose-100 backdrop-blur-md'
            : !isOnline
            ? 'bg-amber-950/90 border-amber-600 text-amber-100 backdrop-blur-md'
            : fila.length > 0
            ? 'bg-sky-950/90 border-sky-600 text-sky-100 backdrop-blur-md'
            : 'bg-emerald-950/90 border-emerald-600 text-emerald-100 backdrop-blur-md'
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {conflitos.length > 0 ? (
              <div className="p-1.5 bg-rose-500/20 text-rose-400 rounded-lg">
                <AlertOctagon className="w-5 h-5 animate-pulse" />
              </div>
            ) : !isOnline ? (
              <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-lg">
                <WifiOff className="w-5 h-5 animate-pulse" />
              </div>
            ) : fila.length > 0 ? (
              <div className="p-1.5 bg-sky-500/20 text-sky-400 rounded-lg">
                <Wifi className="w-5 h-5" />
              </div>
            ) : (
              <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            )}

            <div>
              <div className="text-xs font-bold uppercase tracking-wider">
                {conflitos.length > 0
                  ? `Conflito Detectado (${conflitos.length})`
                  : !isOnline
                  ? 'Modo Canteiro Offline'
                  : pendentesCount > 0
                  ? 'Sincronização Pendente'
                  : 'Sincronização'}
              </div>
              <div className="text-xs text-slate-300">
                {conflitos.length > 0
                  ? 'Versão remota é mais recente. Dados locais preservados.'
                  : !isOnline
                  ? `Operação local garantida. ${pendentesCount} item(ns) na fila.`
                  : syncMsg || `${pendentesCount} item(ns) aguardando confirmação.`}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {conflitos.length > 0 && (
              <button
                onClick={() => setShowConflictModal(true)}
                className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition"
              >
                Resolver
              </button>
            )}

            {isOnline && pendentesCount > 0 && (
              <button
                onClick={handleSync}
                disabled={syncing}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold rounded-lg transition disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
                <span>{syncing ? 'Enviando...' : 'Sincronizar'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Resolução de Conflitos */}
      {showConflictModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
                <AlertOctagon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Conflito de Concorrência na Sincronização</h3>
                <p className="text-xs text-slate-400">
                  O documento no servidor foi alterado por outro usuário enquanto o dispositivo estava offline.
                </p>
              </div>
            </div>

            <div className="space-y-3 max-h-72 overflow-y-auto">
              {conflitos.map((c) => (
                <div key={c.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400 uppercase tracking-wider">{c.tipo}</span>
                    <span className="text-[10px] text-slate-500">ID: {c.id}</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                    {c.conflitoDetalhes?.mensagem}
                  </p>
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => {
                        OfflineStorageService.resolverConflito(c.id, 'descartar_local');
                        atualizarFila();
                        if (conflitos.length <= 1) setShowConflictModal(false);
                      }}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                    >
                      Manter Versão do Servidor
                    </button>
                    <button
                      onClick={() => {
                        OfflineStorageService.resolverConflito(c.id, 'forcar_local');
                        atualizarFila();
                        if (conflitos.length <= 1) setShowConflictModal(false);
                      }}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold"
                    >
                      Forçar Dado Local
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowConflictModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
