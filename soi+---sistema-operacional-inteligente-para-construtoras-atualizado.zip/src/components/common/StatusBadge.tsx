import React from 'react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const getStyle = () => {
    switch (status) {
      // Obra
      case 'planejamento':
        return 'bg-blue-950/80 text-blue-300 border-blue-800/80';
      case 'preparacao':
        return 'bg-amber-950/80 text-amber-300 border-amber-800/80';
      case 'em_execucao':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80';
      case 'em_conclusao':
        return 'bg-purple-950/80 text-purple-300 border-purple-800/80';
      case 'concluida':
        return 'bg-teal-950/80 text-teal-300 border-teal-800/80';
      case 'suspensa':
        return 'bg-rose-950/80 text-rose-300 border-rose-800/80';

      // Atividades
      case 'planejada':
        return 'bg-slate-900 text-slate-300 border-slate-700';
      case 'preparando':
        return 'bg-amber-950/80 text-amber-300 border-amber-800/80';
      case 'liberada':
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-800/80';
      case 'pausada':
        return 'bg-orange-950/80 text-orange-300 border-orange-800/80';
      case 'bloqueada':
        return 'bg-red-950/80 text-red-300 border-red-800/80';

      // Ocorrências
      case 'aberta':
        return 'bg-red-950/80 text-red-300 border-red-800/80';
      case 'em_analise':
        return 'bg-amber-950/80 text-amber-300 border-amber-800/80';
      case 'acao_em_andamento':
        return 'bg-blue-950/80 text-blue-300 border-blue-800/80';
      case 'resolvida':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80';
      case 'encerrada':
        return 'bg-slate-900 text-slate-400 border-slate-700';

      // Gravidade
      case 'critica':
        return 'bg-rose-950 text-rose-200 border-rose-600 font-bold';
      case 'alta':
        return 'bg-orange-950 text-orange-300 border-orange-700';
      case 'media':
        return 'bg-amber-950 text-amber-300 border-amber-700';
      case 'baixa':
        return 'bg-slate-900 text-slate-300 border-slate-700';

      default:
        return 'bg-slate-900 text-slate-300 border-slate-700';
    }
  };

  const getLabel = () => {
    const map: Record<string, string> = {
      planejamento: 'Planejamento',
      preparacao: 'Preparação',
      em_execucao: 'Em Execução',
      em_conclusao: 'Em Conclusão',
      concluida: 'Concluída',
      suspensa: 'Suspensa',

      planejada: 'Planejada',
      preparando: 'Preparando',
      liberada: 'Liberada p/ Campo',
      pausada: 'Pausada',
      bloqueada: 'Bloqueada',

      aberta: 'Aberta',
      em_analise: 'Em Análise',
      acao_em_andamento: 'Ação em Andamento',
      resolvida: 'Resolvida',
      encerrada: 'Encerrada',

      critica: 'CRÍTICA',
      alta: 'Alta',
      media: 'Média',
      baixa: 'Baixa',
    };
    return map[status] || status;
  };

  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1 font-semibold uppercase tracking-wider rounded-md border ${getStyle()} ${sizeClass}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80" />
      {getLabel()}
    </span>
  );
};
