import React from 'react';
import { Calendar, CheckSquare, Play, AlertTriangle, GitFork, Award } from 'lucide-react';
import { CicloOperacional } from '../../domain/types';

interface CycleStepperProps {
  faseAtual: CicloOperacional;
  onSelectFase?: (fase: CicloOperacional) => void;
}

const ETAPAS_CICLO: { key: CicloOperacional; label: string; desc: string; icon: React.ElementType }[] = [
  { key: 'PLANEJAR', label: '1. Planejar', desc: 'Etapas, prazos e dependências', icon: Calendar },
  { key: 'PREPARAR', label: '2. Preparar', desc: 'Prontidão técnica e insumos', icon: CheckSquare },
  { key: 'EXECUTAR', label: '3. Executar', desc: 'Apontamentos e frentes de obra', icon: Play },
  { key: 'DETECTAR', label: '4. Detectar', desc: 'Ocorrências e desvios no canteiro', icon: AlertTriangle },
  { key: 'ORQUESTRAR', label: '5. Orquestrar', desc: 'Ações corretivas e recursos', icon: GitFork },
  { key: 'CONCLUIR', label: '6. Concluir', desc: 'Validação de pendências e entrega', icon: Award },
];

export const CycleStepper: React.FC<CycleStepperProps> = ({ faseAtual, onSelectFase }) => {
  const currentIndex = ETAPAS_CICLO.findIndex((e) => e.key === faseAtual);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl">
      <div className="flex items-center justify-between mb-3">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Ciclo Operacional Determinístico</span>
          <h2 className="text-sm font-semibold text-slate-200">
            Fase Atual do Sistema: <span className="text-amber-400 underline decoration-amber-500/50">{faseAtual}</span>
          </h2>
        </div>
        <span className="text-xs text-slate-400 hidden sm:inline">
          Etapa {currentIndex + 1} de {ETAPAS_CICLO.length}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
        {ETAPAS_CICLO.map((etapa, idx) => {
          const Icon = etapa.icon;
          const isCurrent = etapa.key === faseAtual;
          const isPassed = idx < currentIndex;

          return (
            <button
              key={etapa.key}
              onClick={() => onSelectFase && onSelectFase(etapa.key)}
              className={`flex flex-col items-start p-2.5 rounded-lg border text-left transition-all ${
                isCurrent
                  ? 'bg-amber-500/15 border-amber-500 text-amber-200 shadow-md ring-1 ring-amber-500/30'
                  : isPassed
                  ? 'bg-slate-850 border-emerald-900/50 text-emerald-400 hover:border-emerald-700'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-1.5 w-full mb-1">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isCurrent ? 'text-amber-400' : isPassed ? 'text-emerald-400' : 'text-slate-500'
                  }`}
                />
                <span className="text-xs font-bold truncate">{etapa.label}</span>
              </div>
              <span className="text-[10px] text-slate-400 line-clamp-1">{etapa.desc}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
