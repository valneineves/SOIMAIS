import React, { useState } from 'react';
import {
  HardHat,
  Monitor,
  Smartphone,
  Shield,
  Database,
  History,
  UserCheck,
  ChevronDown,
  LogOut,
  AlertTriangle,
} from 'lucide-react';
import { useAuth } from '../../firebase/auth';
import { UserRole } from '../../domain/types';
import { PWAInstallButton } from './PWAInstallButton';
import { FirestoreService } from '../../services/firestoreService';

interface NavbarProps {
  currentEnv: '/sistema' | '/app';
  onChangeEnv: (env: '/sistema' | '/app') => void;
  onOpenAuditoria: () => void;
  onRefreshData: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentEnv,
  onChangeEnv,
  onOpenAuditoria,
  onRefreshData,
}) => {
  const { userProfile, activeRole, isDemoMode, exitDemoMode, switchDemoRole, logout } = useAuth();
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState(false);

  const handleSeedDemo = async () => {
    if (!userProfile) return;
    setSeeding(true);
    try {
      await FirestoreService.seedDadosDemonstracao(userProfile);
      setSeedSuccess(true);
      onRefreshData();
      setTimeout(() => setSeedSuccess(false), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setSeeding(false);
    }
  };

  const rolesList: { role: UserRole; label: string; desc: string; env: '/sistema' | '/app' }[] = [
    { role: 'gestao', label: 'Gestão Executiva', desc: 'Diretoria e acompanhamento executivo', env: '/sistema' },
    { role: 'administracao', label: 'Administração', desc: 'Contratos, recursos e usuários', env: '/sistema' },
    { role: 'responsavel_obra', label: 'Responsável de Obra', desc: 'Engenheiro residente, liberação e prontidão', env: '/sistema' },
    { role: 'encarregado_mestre', label: 'Mestre / Encarregado', desc: 'Coordenação de frentes e checagem de campo', env: '/app' },
    { role: 'campo', label: 'Equipe de Campo', desc: 'Apontador e líderes operacionais', env: '/app' },
  ];

  return (
    <>
      {/* Persistent Banner if in Demonstration Mode */}
      {isDemoMode && (
        <div className="bg-amber-500 text-slate-950 px-4 py-1.5 text-xs font-bold flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-slate-950" />
            <span>MODO DE DEMONSTRAÇÃO E TESTES — Dados fictícios de homologação identificados</span>
          </div>
          <button
            onClick={exitDemoMode}
            className="px-2.5 py-0.5 rounded bg-slate-950 text-amber-300 hover:bg-slate-900 text-[11px] font-bold"
          >
            Sair do Modo Demo
          </button>
        </div>
      )}

      <header className="sticky top-0 z-40 bg-slate-900/95 border-b border-slate-800 backdrop-blur-md px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 font-black shadow-lg shadow-amber-500/20">
              <HardHat className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-white">SOI<span className="text-amber-400">+</span></span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  Construtora
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">Sistema Operacional de Canteiro e Gestão</p>
            </div>
          </div>

          {/* Environment Switcher Tabs (/sistema vs /app) */}
          <div className="flex items-center p-1 bg-slate-950 border border-slate-800 rounded-xl">
            <button
              onClick={() => onChangeEnv('/sistema')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                currentEnv === '/sistema'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span className="hidden sm:inline">Gestão</span> (/sistema)
            </button>
            <button
              onClick={() => onChangeEnv('/app')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                currentEnv === '/app'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span className="hidden sm:inline">PWA Campo</span> (/app)
            </button>
          </div>

          {/* Actions & Role Display */}
          <div className="flex items-center gap-2">
            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Seed Demo Data Button */}
            <button
              onClick={handleSeedDemo}
              disabled={seeding}
              className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                seedSuccess
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-600'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
              title="Carregar ou restaurar dados de teste claramente identificados"
            >
              <Database className="w-3.5 h-3.5 text-amber-400" />
              <span>{seeding ? 'Carregando...' : seedSuccess ? 'Demo Carregada!' : 'Dados Demo'}</span>
            </button>

            {/* Audit Log Button */}
            <button
              onClick={onOpenAuditoria}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700"
              title="Trilha de Auditoria Imutável"
            >
              <History className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden md:inline">Auditoria</span>
            </button>

            {/* User Profile / Role Indicator */}
            <div className="relative">
              <button
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 hover:border-slate-600 transition"
              >
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span className="truncate max-w-[120px] sm:max-w-none">
                  {userProfile?.nome.split(' ')[0]} ({activeRole})
                </span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {showRoleMenu && (
                <div className="absolute right-0 mt-2 w-72 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3 py-2 border-b border-slate-800 mb-2">
                    <div className="text-xs font-bold text-slate-100">{userProfile?.nome}</div>
                    <div className="text-[11px] text-slate-400">{userProfile?.email}</div>
                    <div className="text-[11px] text-amber-400 font-semibold mt-0.5">
                      Papel: {activeRole?.toUpperCase()} • {userProfile?.cargo}
                    </div>
                  </div>

                  {isDemoMode ? (
                    <div className="space-y-1">
                      <div className="px-2 py-1 text-[10px] text-amber-400 uppercase font-bold">
                        Alternador de Papéis (Modo Demonstração)
                      </div>
                      {rolesList.map((r) => {
                        const isActive = activeRole === r.role;
                        return (
                          <button
                            key={r.role}
                            onClick={() => {
                              switchDemoRole(r.role);
                              setShowRoleMenu(false);
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left text-xs transition ${
                              isActive
                                ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
                                : 'text-slate-300 hover:bg-slate-800'
                            }`}
                          >
                            <span>{r.label}</span>
                            {isActive && <UserCheck className="w-3.5 h-3.5 text-amber-400" />}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-2 text-[11px] text-slate-400 bg-slate-950 rounded-lg border border-slate-800">
                      Sessão autenticada via Firebase Auth. Papel determinado por registro no Firestore (/users).
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-800 mt-2 flex justify-between items-center px-2">
                    <span className="text-[10px] text-slate-500">
                      {isDemoMode ? 'Simulação Ativa' : 'Sessão Real'}
                    </span>
                    <button
                      onClick={() => {
                        logout();
                        setShowRoleMenu(false);
                      }}
                      className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 font-bold"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      {isDemoMode ? 'Encerrar Teste' : 'Desconectar'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>
    </>
  );
};
