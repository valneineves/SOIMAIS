import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  ShieldAlert,
  FileCheck,
  Package,
  Users,
  Wrench,
  Check,
  X,
  Lock,
} from 'lucide-react';
import { Atividade, CriterioProntidao, TipoCriterioProntidao } from '../../domain/types';
import { calcularStatusProntidao } from '../../domain/rules';
import { useAuth } from '../../firebase/auth';

interface ProntidaoMatrixProps {
  atividades: Atividade[];
  onSalvarProntidao: (atividade: Atividade, criterios: CriterioProntidao[]) => Promise<void>;
  onLiberarAtividade: (atividade: Atividade) => Promise<void>;
}

export const ProntidaoMatrix: React.FC<ProntidaoMatrixProps> = ({
  atividades,
  onSalvarProntidao,
  onLiberarAtividade,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [atividadeSelecionada, setAtividadeSelecionada] = useState<Atividade | null>(
    atividades[0] || null
  );
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const getTipoIcon = (tipo: TipoCriterioProntidao) => {
    switch (tipo) {
      case 'projeto':
        return <FileCheck className="w-4 h-4 text-sky-400" />;
      case 'material':
        return <Package className="w-4 h-4 text-amber-400" />;
      case 'mao_de_obra':
        return <Users className="w-4 h-4 text-emerald-400" />;
      case 'equipamento':
        return <Wrench className="w-4 h-4 text-purple-400" />;
      case 'seguranca':
        return <ShieldAlert className="w-4 h-4 text-rose-400" />;
      case 'liberacao':
        return <CheckCircle2 className="w-4 h-4 text-teal-400" />;
      default:
        return <CheckCircle2 className="w-4 h-4 text-slate-400" />;
    }
  };

  const toggleCriterio = async (criterioId: string) => {
    if (!atividadeSelecionada || !userProfile) return;
    setSaving(true);
    setFeedback(null);

    const novosCriterios = atividadeSelecionada.criteriosProntidao.map((c) => {
      if (c.id === criterioId) {
        const novoStatus = !c.atendido;
        return {
          ...c,
          atendido: novoStatus,
          verificadoPor: novoStatus ? userProfile.nome : undefined,
          verificadoEm: novoStatus ? new Date().toISOString() : undefined,
        };
      }
      return c;
    });

    try {
      await onSalvarProntidao(atividadeSelecionada, novosCriterios);
      setAtividadeSelecionada({
        ...atividadeSelecionada,
        criteriosProntidao: novosCriterios,
      });
      setFeedback('Critério atualizado e registrado na auditoria.');
      setTimeout(() => setFeedback(null), 3000);
    } finally {
      setSaving(false);
    }
  };

  const handleLiberar = async () => {
    if (!atividadeSelecionada) return;
    setSaving(true);
    try {
      await onLiberarAtividade(atividadeSelecionada);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Controle de Prontidão Operacional
            </span>
            <h2 className="text-lg font-bold text-white">Matriz de Liberação de Frentes de Obra</h2>
            <p className="text-xs text-slate-400">
              Nenhuma atividade pode ser liberada para o campo sem atendimento de 100% dos critérios obrigatórios (Projetos, Materiais, Mão de Obra, Equipamentos e Segurança).
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-300">
              Atividades Monitoradas: <strong className="text-white">{atividades.length}</strong>
            </span>
          </div>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-600 text-emerald-200 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          {feedback}
        </div>
      )}

      {/* Grid: Atividades selector & Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Atividades List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg space-y-2">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider px-2 py-1">
            Selecione a Atividade
          </div>

          <div className="space-y-2 max-h-[550px] overflow-y-auto">
            {atividades.map((ativ) => {
              const prontidao = calcularStatusProntidao(ativ);
              const isSelected = atividadeSelecionada?.id === ativ.id;

              return (
                <button
                  key={ativ.id}
                  onClick={() => setAtividadeSelecionada(ativ)}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-bold truncate">{ativ.nome}</span>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                        ativ.status === 'liberada'
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                          : ativ.status === 'concluida'
                          ? 'bg-teal-950 text-teal-400 border border-teal-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {ativ.status}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                    <span className="truncate">{ativ.localizacao}</span>
                    <span
                      className={`font-semibold ${
                        prontidao.todosObrigatoriosAtendidos ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {prontidao.atendidosObrigatorios}/{prontidao.totalObrigatorios} prontos
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        prontidao.todosObrigatoriosAtendidos ? 'bg-emerald-500' : 'bg-amber-500'
                      }`}
                      style={{
                        width: `${
                          prontidao.totalObrigatorios > 0
                            ? (prontidao.atendidosObrigatorios / prontidao.totalObrigatorios) * 100
                            : 100
                        }%`,
                      }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Detailed Checklist */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          {atividadeSelecionada ? (
            <div>
              {/* Header of selected atividade */}
              <div className="border-b border-slate-800 pb-4 mb-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      Frente de Trabalho
                    </span>
                    <h3 className="text-base font-bold text-white">{atividadeSelecionada.nome}</h3>
                    <p className="text-xs text-slate-400 mt-1">{atividadeSelecionada.descricao}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-400">Localização</div>
                    <div className="text-xs font-bold text-slate-200">{atividadeSelecionada.localizacao}</div>
                  </div>
                </div>

                {/* Predecessors / Dependencies status */}
                {atividadeSelecionada.dependencias && atividadeSelecionada.dependencias.length > 0 && (
                  <div className="mt-3 p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Predecessoras Obrigatórias:</span>
                    <span className="text-slate-300 font-mono">
                      {atividadeSelecionada.dependencias.length} dependência(s) vinculada(s)
                    </span>
                  </div>
                )}
              </div>

              {/* Checklist items */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Checklist de Critérios Obrigatórios
                </div>

                {atividadeSelecionada.criteriosProntidao?.map((crit) => (
                  <div
                    key={crit.id}
                    onClick={() => toggleCriterio(crit.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-start justify-between gap-3 ${
                      crit.atendido
                        ? 'bg-emerald-950/30 border-emerald-800/80 hover:bg-emerald-950/50'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                        {getTipoIcon(crit.tipo)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-200">{crit.titulo}</span>
                          {crit.obrigatorio && (
                            <span className="text-[10px] font-bold uppercase px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
                              Obrigatório
                            </span>
                          )}
                        </div>

                        {crit.notas && <p className="text-[11px] text-amber-300 mt-1">{crit.notas}</p>}

                        {crit.verificadoPor && (
                          <div className="text-[10px] text-slate-400 mt-1">
                            Verificado por: <strong className="text-slate-300">{crit.verificadoPor}</strong>
                            {crit.verificadoEm && (
                              <span> • {new Date(crit.verificadoEm).toLocaleDateString('pt-BR')}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 border transition ${
                        crit.atendido
                          ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                          : 'border-slate-700 bg-slate-800 text-transparent hover:border-slate-500'
                      }`}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </div>
                  </div>
                ))}
              </div>

              {/* Bottom Action: Release Activity */}
              <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                {(() => {
                  const p = calcularStatusProntidao(atividadeSelecionada);
                  return (
                    <div className="text-xs text-slate-400">
                      Status da Prontidão:{' '}
                      <strong
                        className={p.todosObrigatoriosAtendidos ? 'text-emerald-400' : 'text-amber-400'}
                      >
                        {p.todosObrigatoriosAtendidos
                          ? '100% ATENDIDO - APTO PARA LIBERAÇÃO'
                          : `${p.pendentes.length} CRITÉRIO(S) PENDENTE(S)`}
                      </strong>
                    </div>
                  );
                })()}

                {atividadeSelecionada.status === 'liberada' || atividadeSelecionada.status === 'em_execucao' ? (
                  <span className="px-4 py-2 bg-emerald-950 border border-emerald-700 text-emerald-300 text-xs font-bold rounded-xl flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Atividade Liberada para Execução em Campo
                  </span>
                ) : (
                  <button
                    onClick={handleLiberar}
                    disabled={
                      saving ||
                      !calcularStatusProntidao(atividadeSelecionada).todosObrigatoriosAtendidos ||
                      activeRole === 'campo'
                    }
                    className="w-full sm:w-auto px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition shadow-lg active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Liberar Frente para o Campo (/app)</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500">
              Selecione uma atividade para auditar a prontidão.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
