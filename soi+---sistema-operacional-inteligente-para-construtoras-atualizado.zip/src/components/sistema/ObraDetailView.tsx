import React, { useState } from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  Plus,
  ArrowRight,
  ChevronRight,
  ChevronDown,
  Lock,
  GitBranch,
  Shield,
  Activity,
} from 'lucide-react';
import {
  Atividade,
  Etapa,
  Execucao,
  Obra,
  StatusAtividade,
} from '../../domain/types';
import { StatusBadge } from '../common/StatusBadge';
import { calcularStatusProntidao } from '../../domain/rules';
import { useAuth } from '../../firebase/auth';

interface ObraDetailViewProps {
  obra: Obra;
  etapas: Etapa[];
  atividades: Atividade[];
  execucoes: Execucao[];
  onAdicionarEtapa: (nome: string, ordem: number) => Promise<void>;
  onAdicionarAtividade: (etapaId: string, nome: string, localizacao: string, dependencias: string[]) => Promise<void>;
  onAtualizarStatusAtividade: (ativ: Atividade, novoStatus: StatusAtividade) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
  onSelectAtividadeParaProntidao: (ativ: Atividade) => void;
}

export const ObraDetailView: React.FC<ObraDetailViewProps> = ({
  obra,
  etapas,
  atividades,
  execucoes,
  onAdicionarEtapa,
  onAdicionarAtividade,
  onAtualizarStatusAtividade,
  onSelectAtividadeParaProntidao,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [etapaExpandida, setEtapaExpandida] = useState<Record<string, boolean>>(
    etapas.reduce((acc, e) => ({ ...acc, [e.id]: true }), {})
  );

  const [showNovaEtapaModal, setShowNovaEtapaModal] = useState(false);
  const [novaEtapaNome, setNovaEtapaNome] = useState('');

  const [showNovaAtivModal, setShowNovaAtivModal] = useState(false);
  const [ativEtapaId, setAtivEtapaId] = useState(etapas[0]?.id || '');
  const [ativNome, setAtivNome] = useState('');
  const [ativLocalizacao, setAtivLocalizacao] = useState('');
  const [ativDependencias, setAtivDependencias] = useState<string[]>([]);

  const [transicaoFeedback, setTransicaoFeedback] = useState<{ id: string; msg: string; bloqueios?: string[] } | null>(null);

  const toggleEtapa = (id: string) => {
    setEtapaExpandida((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCreateEtapa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!novaEtapaNome.trim()) return;
    await onAdicionarEtapa(novaEtapaNome, etapas.length + 1);
    setNovaEtapaNome('');
    setShowNovaEtapaModal(false);
  };

  const handleCreateAtividade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ativNome.trim() || !ativEtapaId) return;
    await onAdicionarAtividade(ativEtapaId, ativNome, ativLocalizacao, ativDependencias);
    setAtivNome('');
    setAtivLocalizacao('');
    setAtivDependencias([]);
    setShowNovaAtivModal(false);
  };

  const handleMudarStatus = async (ativ: Atividade, novoStatus: StatusAtividade) => {
    setTransicaoFeedback(null);
    const res = await onAtualizarStatusAtividade(ativ, novoStatus);
    if (!res.sucesso) {
      setTransicaoFeedback({
        id: ativ.id,
        msg: res.erro || 'Transição rejeitada pelo motor de regras.',
        bloqueios: res.bloqueios,
      });
      setTimeout(() => setTransicaoFeedback(null), 6000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Hierarquia Construtiva: Obra → Etapa → Atividade → Execução
          </span>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span>{obra.nome}</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              {obra.codigo}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {obra.endereco} • Responsável: <strong className="text-slate-200">{obra.responsavelNome}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNovaEtapaModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Nova Etapa</span>
          </button>
          <button
            onClick={() => {
              setAtivEtapaId(etapas[0]?.id || '');
              setShowNovaAtivModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold transition shadow-md"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Nova Atividade</span>
          </button>
        </div>
      </div>

      {/* Etapas & Atividades Hierarchy */}
      <div className="space-y-4">
        {etapas.map((etapa) => {
          const ativsEtapa = atividades.filter((a) => a.etapaId === etapa.id);
          const isExpanded = etapaExpandida[etapa.id];
          const totalAtivs = ativsEtapa.length;
          const concluidas = ativsEtapa.filter((a) => a.status === 'concluida').length;
          const progresso = totalAtivs > 0 ? Math.round((concluidas / totalAtivs) * 100) : 0;

          return (
            <div key={etapa.id} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
              {/* Etapa Banner */}
              <div
                onClick={() => toggleEtapa(etapa.id)}
                className="p-4 bg-slate-850 hover:bg-slate-800/80 cursor-pointer flex items-center justify-between border-b border-slate-800 transition select-none"
              >
                <div className="flex items-center gap-3">
                  {isExpanded ? (
                    <ChevronDown className="w-4 h-4 text-amber-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  )}
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-amber-400">#{etapa.ordem}</span>
                    <h3 className="text-sm font-bold text-white">{etapa.nome}</h3>
                    <StatusBadge status={etapa.status} size="sm" />
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs text-slate-400">
                  <span>
                    {concluidas}/{totalAtivs} Atividades Concluídas ({progresso}%)
                  </span>
                  <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded-full transition-all"
                      style={{ width: `${progresso}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Atividades List under Etapa */}
              {isExpanded && (
                <div className="p-4 space-y-3">
                  {ativsEtapa.length === 0 ? (
                    <div className="text-center py-6 text-xs text-slate-500">
                      Nenhuma atividade cadastrada nesta etapa.
                    </div>
                  ) : (
                    ativsEtapa.map((ativ) => {
                      const prontidao = calcularStatusProntidao(ativ);
                      const execsAtiv = execucoes.filter((ex) => ex.atividadeId === ativ.id);
                      const hasFeedback = transicaoFeedback?.id === ativ.id;

                      return (
                        <div
                          key={ativ.id}
                          className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition space-y-3"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2.5">
                              <StatusBadge status={ativ.status} size="sm" />
                              <span className="text-sm font-bold text-white">{ativ.nome}</span>
                              <span className="text-xs text-slate-400">({ativ.localizacao})</span>
                            </div>

                            <div className="flex items-center gap-2">
                              {/* Readiness indicator */}
                              <button
                                onClick={() => onSelectAtividadeParaProntidao(ativ)}
                                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                                  prontidao.todosObrigatoriosAtendidos
                                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300 hover:bg-emerald-900/60'
                                    : 'bg-amber-950/60 border-amber-800 text-amber-300 hover:bg-amber-900/60'
                                }`}
                              >
                                <Shield className="w-3.5 h-3.5" />
                                <span>Prontidão: {prontidao.atendidosObrigatorios}/{prontidao.totalObrigatorios}</span>
                              </button>

                              {/* Avanço % */}
                              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono font-bold text-amber-400">
                                {ativ.percentualAvanco || 0}%
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-slate-300 leading-relaxed">{ativ.descricao}</p>

                          {/* Predecessoras / Dependências */}
                          {ativ.dependencias && ativ.dependencias.length > 0 && (
                            <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-900/50 p-2 rounded-lg border border-slate-800/60">
                              <GitBranch className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                              <span>Depende de: </span>
                              <div className="flex flex-wrap gap-1.5">
                                {ativ.dependencias.map((depId) => {
                                  const dep = atividades.find((a) => a.id === depId);
                                  return (
                                    <span
                                      key={depId}
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                        dep?.status === 'concluida'
                                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                                      }`}
                                    >
                                      {dep ? dep.nome : depId} ({dep?.status || 'desconhecido'})
                                    </span>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* Rule engine feedback message */}
                          {hasFeedback && (
                            <div className="p-3 bg-red-950/90 border border-red-600 rounded-xl text-red-200 text-xs space-y-1">
                              <div className="font-bold flex items-center gap-1.5">
                                <Lock className="w-4 h-4 text-red-400 shrink-0" />
                                Transição Bloqueada:
                              </div>
                              <p>{transicaoFeedback.msg}</p>
                              {transicaoFeedback.bloqueios && (
                                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-red-300 mt-1">
                                  {transicaoFeedback.bloqueios.map((b, i) => (
                                    <li key={i}>{b}</li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          )}

                          {/* Quick deterministic transition triggers */}
                          <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs">
                            <span className="text-[11px] text-slate-500">
                              Encarregado: <strong className="text-slate-400">{ativ.encarregadoNome}</strong>
                            </span>

                            <div className="flex items-center gap-1.5">
                              {ativ.status === 'planejada' && (
                                <button
                                  onClick={() => handleMudarStatus(ativ, 'preparando')}
                                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded text-[11px] font-semibold"
                                >
                                  Iniciar Preparação
                                </button>
                              )}

                              {ativ.status === 'preparando' && (
                                <button
                                  onClick={() => handleMudarStatus(ativ, 'liberada')}
                                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-[11px] font-bold shadow-xs"
                                >
                                  Liberar para Execução
                                </button>
                              )}

                              {ativ.status === 'liberada' && (
                                <button
                                  onClick={() => handleMudarStatus(ativ, 'em_execucao')}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold shadow-xs"
                                >
                                  Iniciar no Campo
                                </button>
                              )}

                              {ativ.status === 'em_execucao' && (
                                <>
                                  <button
                                    onClick={() => handleMudarStatus(ativ, 'pausada')}
                                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-orange-400 border border-slate-700 rounded text-[11px]"
                                  >
                                    Pausar
                                  </button>
                                  <button
                                    onClick={() => handleMudarStatus(ativ, 'concluida')}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold"
                                  >
                                    Finalizar Atividade
                                  </button>
                                </>
                              )}

                              {ativ.status === 'pausada' && (
                                <button
                                  onClick={() => handleMudarStatus(ativ, 'em_execucao')}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold"
                                >
                                  Retomar Execução
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Modal Nova Etapa */}
      {showNovaEtapaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-400" />
              Adicionar Etapa Construtiva
            </h3>
            <form onSubmit={handleCreateEtapa} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Nome da Etapa</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Instalações Hidráulicas e Elétricas"
                  value={novaEtapaNome}
                  onChange={(e) => setNovaEtapaNome(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNovaEtapaModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold"
                >
                  Criar Etapa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Nova Atividade */}
      {showNovaAtivModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400" />
              Adicionar Atividade Operacional
            </h3>
            <form onSubmit={handleCreateAtividade} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Etapa Vinculada</label>
                <select
                  value={ativEtapaId}
                  onChange={(e) => setAtivEtapaId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                >
                  {etapas.map((et) => (
                    <option key={et.id} value={et.id}>
                      {et.ordem}. {et.nome}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Nome da Atividade</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Armação e forma das vigas do 4º pavimento"
                  value={ativNome}
                  onChange={(e) => setAtivNome(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Localização no Canteiro</label>
                <input
                  type="text"
                  placeholder="Ex: Bloco B - 4º Pavimento"
                  value={ativLocalizacao}
                  onChange={(e) => setAtivLocalizacao(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Predecessoras */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Atividades Predecessoras (Dependências)
                </label>
                <div className="max-h-36 overflow-y-auto space-y-1 bg-slate-950 border border-slate-700 p-2 rounded-lg text-xs">
                  {atividades.map((a) => (
                    <label key={a.id} className="flex items-center gap-2 text-slate-300 hover:text-white cursor-pointer py-1">
                      <input
                        type="checkbox"
                        checked={ativDependencias.includes(a.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAtivDependencias([...ativDependencias, a.id]);
                          } else {
                            setAtivDependencias(ativDependencias.filter((id) => id !== a.id));
                          }
                        }}
                        className="accent-amber-500"
                      />
                      <span className="truncate">{a.nome} ({a.status})</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNovaAtivModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold"
                >
                  Criar Atividade
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
