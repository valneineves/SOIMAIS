import React, { useState } from 'react';
import {
  FileText,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  ShieldAlert,
  Calendar,
  Check,
} from 'lucide-react';
import { CategoriaPendencia, Pendencia } from '../../domain/types';
import { useAuth } from '../../firebase/auth';

interface PendenciasManagerProps {
  obraId: string;
  pendencias: Pendencia[];
  onSalvarPendencia: (p: Pendencia) => Promise<void>;
  onConcluirPendencia: (p: Pendencia) => Promise<void>;
}

export const PendenciasManager: React.FC<PendenciasManagerProps> = ({
  obraId,
  pendencias,
  onSalvarPendencia,
  onConcluirPendencia,
}) => {
  const { userProfile } = useAuth();
  const [showNovaModal, setShowNovaModal] = useState(false);
  const [novoTitulo, setNovoTitulo] = useState('');
  const [novaDescricao, setNovaDescricao] = useState('');
  const [novaCategoria, setNovaCategoria] = useState<CategoriaPendencia>('documental');
  const [novoPrazo, setNovoPrazo] = useState('');
  const [novoResponsavel, setNovoResponsavel] = useState('');
  const [novoObrigatoria, setNovoObrigatoria] = useState(true);
  const [saving, setSaving] = useState(false);

  const handleCriar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    setSaving(true);
    try {
      const nova: Pendencia = {
        id: 'pend_' + Date.now(),
        obraId,
        titulo: novoTitulo,
        descricao: novaDescricao,
        categoria: novaCategoria,
        obrigatoria: novoObrigatoria,
        status: 'aberta',
        responsavelNome: novoResponsavel || userProfile.nome,
        prazo: novoPrazo || new Date(Date.now() + 86400000 * 15).toISOString().split('T')[0],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await onSalvarPendencia(nova);
      setShowNovaModal(false);
      setNovoTitulo('');
      setNovaDescricao('');
    } finally {
      setSaving(false);
    }
  };

  const getCategoriaLabel = (cat: CategoriaPendencia) => {
    const map: Record<CategoriaPendencia, string> = {
      documental: 'Documental / Alvarás',
      tecnica: 'Técnica / Ensaios',
      insumo: 'Insumos Críticos',
      fiscalizacao: 'Fiscalização de Obra',
      vistoria: 'Vistoria e Habite-se',
    };
    return map[cat] || cat;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Controle de Pendências Operacionais
          </span>
          <h2 className="text-lg font-bold text-white">Pendências Obrigatórias e Técnicas</h2>
          <p className="text-xs text-slate-400">
            Regra Determinística: Nenhuma obra pode ser transicionada para status "Concluída" enquanto existirem pendências marcadas como obrigatórias em aberto.
          </p>
        </div>
        <button
          onClick={() => setShowNovaModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold shadow-md transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Pendência</span>
        </button>
      </div>

      {/* List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {pendencias.map((pend) => {
          const isConcluida = pend.status === 'concluida';
          return (
            <div
              key={pend.id}
              className={`p-4 rounded-xl border transition flex flex-col justify-between ${
                isConcluida
                  ? 'bg-slate-950/40 border-slate-800/80 text-slate-400'
                  : pend.obrigatoria
                  ? 'bg-slate-900 border-amber-600/60 shadow-md'
                  : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {getCategoriaLabel(pend.categoria)}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {pend.obrigatoria && (
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1">
                        <ShieldAlert className="w-3 h-3 text-rose-400" />
                        Bloqueia Obra
                      </span>
                    )}
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        isConcluida
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {pend.status}
                    </span>
                  </div>
                </div>

                <h4 className={`text-sm font-bold ${isConcluida ? 'text-slate-400 line-through' : 'text-white'}`}>
                  {pend.titulo}
                </h4>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{pend.descricao}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div>
                  <div className="text-[11px] text-slate-400">
                    Responsável: <strong className="text-slate-300">{pend.responsavelNome}</strong>
                  </div>
                  <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                    <Calendar className="w-3 h-3" />
                    Prazo: {new Date(pend.prazo).toLocaleDateString('pt-BR')}
                  </div>
                </div>

                {!isConcluida ? (
                  <button
                    onClick={() => onConcluirPendencia(pend)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow-sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Concluir</span>
                  </button>
                ) : (
                  <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {pend.concluidaPor ? `Por ${pend.concluidaPor}` : 'Concluída'}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Nova Pendência */}
      {showNovaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-amber-500" />
              Adicionar Pendência de Obra
            </h3>

            <form onSubmit={handleCriar} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Título</label>
                <input
                  type="text"
                  required
                  value={novoTitulo}
                  onChange={(e) => setNovoTitulo(e.target.value)}
                  placeholder="Ex: Laudo de Estanqueidade da Cobertura"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Categoria</label>
                  <select
                    value={novaCategoria}
                    onChange={(e) => setNovaCategoria(e.target.value as CategoriaPendencia)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                    <option value="documental">Documental / Alvarás</option>
                    <option value="tecnica">Técnica / Ensaios</option>
                    <option value="insumo">Insumos Críticos</option>
                    <option value="fiscalizacao">Fiscalização de Obra</option>
                    <option value="vistoria">Vistoria e Habite-se</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Prazo Limite</label>
                  <input
                    type="date"
                    required
                    value={novoPrazo}
                    onChange={(e) => setNovoPrazo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                  </input>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Responsável</label>
                <input
                  type="text"
                  placeholder="Nome do responsável técnico ou administrativo"
                  value={novoResponsavel}
                  onChange={(e) => setNovoResponsavel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Descrição</label>
                <textarea
                  rows={3}
                  required
                  value={novaDescricao}
                  onChange={(e) => setNovaDescricao(e.target.value)}
                  placeholder="Detalhes sobre a exigência e documentos necessários..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-white">Pendência Obrigatória</div>
                  <div className="text-[11px] text-slate-400">
                    Se marcado, bloqueia a conclusão da obra no sistema.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={novoObrigatoria}
                  onChange={(e) => setNovoObrigatoria(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNovaModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-md"
                >
                  Salvar Pendência
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
