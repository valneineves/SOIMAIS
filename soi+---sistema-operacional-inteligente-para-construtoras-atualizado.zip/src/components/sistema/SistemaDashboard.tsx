import React, { useState } from 'react';
import {
  Layers,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
  Users2,
  Building,
  CheckCircle,
  Briefcase,
  ChevronDown,
  UserCheck,
} from 'lucide-react';
import {
  Atividade,
  CicloOperacional,
  CriterioProntidao,
  Etapa,
  Execucao,
  Obra,
  Ocorrencia,
  Pendencia,
  Recurso,
  StatusAtividade,
  StatusObra,
} from '../../domain/types';
import { calcularCicloOperacionalObra } from '../../domain/rules';
import { CycleStepper } from '../common/CycleStepper';
import { ObrasManager } from './ObrasManager';
import { ObraDetailView } from './ObraDetailView';
import { ProntidaoMatrix } from './ProntidaoMatrix';
import { OcorrenciasManager } from './OcorrenciasManager';
import { PendenciasManager } from './PendenciasManager';
import { UsuariosManager } from './UsuariosManager';
import { useAuth } from '../../firebase/auth';

interface SistemaDashboardProps {
  obras: Obra[];
  etapas: Etapa[];
  atividades: Atividade[];
  execucoes: Execucao[];
  ocorrencias: Ocorrencia[];
  pendencias: Pendencia[];
  recursos: Recurso[];
  obraAtiva: Obra;
  onSelectObra: (obra: Obra) => void;
  onSalvarObra: (obra: Obra) => Promise<void>;
  onAtualizarStatusObra: (obra: Obra, novoStatus: StatusObra) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
  onAdicionarEtapa: (nome: string, ordem: number) => Promise<void>;
  onAdicionarAtividade: (etapaId: string, nome: string, localizacao: string, dependencias: string[]) => Promise<void>;
  onAtualizarStatusAtividade: (ativ: Atividade, novoStatus: StatusAtividade) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
  onSalvarProntidao: (ativ: Atividade, criterios: CriterioProntidao[]) => Promise<void>;
  onSalvarOcorrencia: (oco: Ocorrencia) => Promise<void>;
  onEncerrarOcorrencia: (oco: Ocorrencia, resolucaoTexto: string) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
  onSalvarPendencia: (p: Pendencia) => Promise<void>;
  onConcluirPendencia: (p: Pendencia) => Promise<void>;
}

export const SistemaDashboard: React.FC<SistemaDashboardProps> = ({
  obras,
  etapas,
  atividades,
  execucoes,
  ocorrencias,
  pendencias,
  recursos,
  obraAtiva,
  onSelectObra,
  onSalvarObra,
  onAtualizarStatusObra,
  onAdicionarEtapa,
  onAdicionarAtividade,
  onAtualizarStatusAtividade,
  onSalvarProntidao,
  onSalvarOcorrencia,
  onEncerrarOcorrencia,
  onSalvarPendencia,
  onConcluirPendencia,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'cronograma' | 'prontidao' | 'ocorrencias' | 'pendencias' | 'obras' | 'recursos' | 'usuarios'
  >('cronograma');

  // Determina a fase do ciclo da obra ativa
  const ciclo = calcularCicloOperacionalObra(obraAtiva, atividades, ocorrencias);

  const tabs: { key: typeof activeTab; label: string; icon: React.ElementType; badge?: number }[] = [
    { key: 'cronograma', label: 'Cronograma & Hierarquia', icon: Layers },
    { key: 'prontidao', label: 'Matriz de Prontidão', icon: ShieldCheck },
    {
      key: 'ocorrencias',
      label: 'Ocorrências & Ações',
      icon: AlertTriangle,
      badge: ocorrencias.filter((o) => o.status !== 'encerrada').length,
    },
    {
      key: 'pendencias',
      label: 'Pendências Obrigatórias',
      icon: FileCheck2,
      badge: pendencias.filter((p) => p.status !== 'concluida').length,
    },
    { key: 'recursos', label: 'Recursos & Equipes', icon: Users2 },
    { key: 'obras', label: 'Obras da Construtora', icon: Building, badge: obras.length },
    ...(activeRole === 'gestao' || activeRole === 'administracao'
      ? [{ key: 'usuarios' as const, label: 'Equipe & Aprovações', icon: UserCheck }]
      : []),
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Bar with Obra Selector & Quick Indicators */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
            <Building className="w-6 h-6" />
          </div>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Obra em Foco no /sistema
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <select
                value={obraAtiva.id}
                onChange={(e) => {
                  const o = obras.find((ob) => ob.id === e.target.value);
                  if (o) onSelectObra(o);
                }}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-sm font-bold text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                {obras.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.nome} ({o.codigo})
                  </option>
                ))}
              </select>
              <span className="text-xs text-slate-400 hidden sm:inline">
                • {obraAtiva.cidade}
              </span>
            </div>
          </div>
        </div>

        {/* Indicators */}
        <div className="flex items-center gap-3 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center shrink-0">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Atividades</div>
            <div className="text-xs font-bold text-white">{ciclo.concluidas}/{ciclo.totalAtividades} ({ciclo.percentualGeral}%)</div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center shrink-0">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Frente Ativa</div>
            <div className="text-xs font-bold text-emerald-400">{ciclo.emExecucao} em execução</div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center shrink-0">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Ocorrências</div>
            <div className={`text-xs font-bold ${ciclo.ocorrenciasAbertas > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {ciclo.ocorrenciasAbertas} abertas
            </div>
          </div>
        </div>
      </div>

      {/* Cycle Stepper */}
      <CycleStepper
        faseAtual={ciclo.etapaAtual}
        onSelectFase={(fase) => {
          if (fase === 'PLANEJAR') setActiveTab('cronograma');
          if (fase === 'PREPARAR') setActiveTab('prontidao');
          if (fase === 'EXECUTAR') setActiveTab('cronograma');
          if (fase === 'DETECTAR') setActiveTab('ocorrencias');
          if (fase === 'ORQUESTRAR') setActiveTab('recursos');
          if (fase === 'CONCLUIR') setActiveTab('pendencias');
        }}
      />

      {/* Tabs navigation */}
      <div className="flex items-center gap-1.5 border-b border-slate-800 overflow-x-auto pb-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition shrink-0 ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {typeof tab.badge === 'number' && tab.badge > 0 && (
                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                  tab.key === 'ocorrencias'
                    ? 'bg-rose-500 text-slate-950'
                    : 'bg-amber-500 text-slate-950'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      {activeTab === 'cronograma' && (
        <ObraDetailView
          obra={obraAtiva}
          etapas={etapas}
          atividades={atividades}
          execucoes={execucoes}
          onAdicionarEtapa={onAdicionarEtapa}
          onAdicionarAtividade={onAdicionarAtividade}
          onAtualizarStatusAtividade={onAtualizarStatusAtividade}
          onSelectAtividadeParaProntidao={(ativ) => setActiveTab('prontidao')}
        />
      )}

      {activeTab === 'prontidao' && (
        <ProntidaoMatrix
          atividades={atividades}
          onSalvarProntidao={onSalvarProntidao}
          onLiberarAtividade={async (ativ) => {
            await onAtualizarStatusAtividade(ativ, 'liberada');
          }}
        />
      )}

      {activeTab === 'ocorrencias' && (
        <OcorrenciasManager
          obraId={obraAtiva.id}
          ocorrencias={ocorrencias}
          onSalvarOcorrencia={onSalvarOcorrencia}
          onEncerrarOcorrencia={onEncerrarOcorrencia}
        />
      )}

      {activeTab === 'pendencias' && (
        <PendenciasManager
          obraId={obraAtiva.id}
          pendencias={pendencias}
          onSalvarPendencia={onSalvarPendencia}
          onConcluirPendencia={onConcluirPendencia}
        />
      )}

      {activeTab === 'recursos' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Alocação Operacional
              </span>
              <h2 className="text-lg font-bold text-white">Equipamentos, Equipes e Insumos Críticos</h2>
              <p className="text-xs text-slate-400">
                Acompanhamento dos recursos essenciais alocados à obra para evitar paralisações de frentes.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recursos.map((rec) => (
              <div key={rec.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                    {rec.tipo.replace('_', ' ')}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    rec.disponibilidade === 'em_uso'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : rec.disponibilidade === 'disponivel'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}>
                    {rec.disponibilidade.replace('_', ' ')}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white">{rec.nome}</h4>
                <div className="text-xs text-slate-300">
                  Quantidade: <strong className="text-amber-400">{rec.quantidade} {rec.unidade}</strong>
                </div>
                {rec.observacao && (
                  <p className="text-[11px] text-slate-400 bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                    {rec.observacao}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'obras' && (
        <ObrasManager
          obras={obras}
          etapas={etapas}
          atividades={atividades}
          ocorrencias={ocorrencias}
          pendencias={pendencias}
          onSelectObra={(o) => {
            onSelectObra(o);
            setActiveTab('cronograma');
          }}
          onSalvarObra={onSalvarObra}
          onAtualizarStatusObra={onAtualizarStatusObra}
        />
      )}

      {activeTab === 'usuarios' && <UsuariosManager />}
    </div>
  );
};
