import React, { useState } from 'react';
import {
  AlertTriangle,
  Plus,
  CheckCircle,
  Clock,
  Shield,
  CheckSquare,
  FileText,
  AlertOctagon,
  Lock,
} from 'lucide-react';
import { AcaoOcorrencia, GravidadeOcorrencia, Ocorrencia, TipoOcorrencia } from '../../domain/types';
import { StatusBadge } from '../common/StatusBadge';
import { useAuth } from '../../firebase/auth';

interface OcorrenciasManagerProps {
  obraId: string;
  ocorrencias: Ocorrencia[];
  onSalvarOcorrencia: (oco: Ocorrencia) => Promise<void>;
  onEncerrarOcorrencia: (oco: Ocorrencia, resolucaoTexto: string) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
}

export const OcorrenciasManager: React.FC<OcorrenciasManagerProps> = ({
  obraId,
  ocorrencias,
  onSalvarOcorrencia,
  onEncerrarOcorrencia,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [selectedOcorrencia, setSelectedOcorrencia] = useState<Ocorrencia | null>(
    ocorrencias[0] || null
  );
  const [showNovaModal, setShowNovaModal] = useState(false);
  const [resolucaoTexto, setResolucaoTexto] = useState('');
  const [novaAcaoTexto, setNovaAcaoTexto] = useState('');
  const [novaAcaoResponsavel, setNovaAcaoResponsavel] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [bloqueiosList, setBloqueiosList] = useState<string[]>([]);

  // Novo modal form state
  const [novoTitulo, setNovoTitulo] = useState('');
  const [novaDescricao, setNovaDescricao] = useState('');
  const [novoTipo, setNovoTipo] = useState<TipoOcorrencia>('seguranca');
  const [novaGravidade, setNovaGravidade] = useState<GravidadeOcorrencia>('media');

  const handleCriarOcorrencia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    const codigo = `OCO-${String(ocorrencias.length + 1).padStart(3, '0')}-DEMO`;
    const novaOco: Ocorrencia = {
      id: 'oco_' + Date.now(),
      obraId,
      codigo,
      titulo: novoTitulo,
      descricao: novaDescricao,
      tipo: novoTipo,
      gravidade: novaGravidade,
      status: 'aberta',
      acoesNecessarias: [],
      registradoPorUid: userProfile.uid,
      registradoPorNome: userProfile.nome,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await onSalvarOcorrencia(novaOco);
    setShowNovaModal(false);
    setNovoTitulo('');
    setNovaDescricao('');
    setSelectedOcorrencia(novaOco);
    setSuccessMsg(`Ocorrência ${codigo} registrada com sucesso.`);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleAdicionarAcao = async () => {
    if (!selectedOcorrencia || !novaAcaoTexto.trim()) return;

    const novaAcao: AcaoOcorrencia = {
      id: 'ac_' + Date.now(),
      descricao: novaAcaoTexto.trim(),
      responsavelNome: novaAcaoResponsavel.trim() || userProfile?.nome || 'Responsável',
      concluida: false,
    };

    const atualizada: Ocorrencia = {
      ...selectedOcorrencia,
      status: selectedOcorrencia.status === 'aberta' ? 'acao_em_andamento' : selectedOcorrencia.status,
      acoesNecessarias: [...(selectedOcorrencia.acoesNecessarias || []), novaAcao],
      updatedAt: new Date().toISOString(),
    };

    await onSalvarOcorrencia(atualizada);
    setSelectedOcorrencia(atualizada);
    setNovaAcaoTexto('');
    setNovaAcaoResponsavel('');
  };

  const handleToggleAcao = async (acaoId: string) => {
    if (!selectedOcorrencia) return;

    const acoesAtualizadas = selectedOcorrencia.acoesNecessarias.map((a) => {
      if (a.id === acaoId) {
        return {
          ...a,
          concluida: !a.concluida,
          concluidaEm: !a.concluida ? new Date().toISOString() : undefined,
        };
      }
      return a;
    });

    const atualizada: Ocorrencia = {
      ...selectedOcorrencia,
      acoesNecessarias: acoesAtualizadas,
      updatedAt: new Date().toISOString(),
    };

    await onSalvarOcorrencia(atualizada);
    setSelectedOcorrencia(atualizada);
  };

  const handleEncerrar = async () => {
    if (!selectedOcorrencia) return;
    setErrorMsg(null);
    setBloqueiosList([]);

    const resultado = await onEncerrarOcorrencia(selectedOcorrencia, resolucaoTexto);
    if (!resultado.sucesso) {
      setErrorMsg(resultado.erro || 'Falha ao encerrar ocorrência.');
      setBloqueiosList(resultado.bloqueios || []);
    } else {
      setSuccessMsg('Ocorrência encerrada com sucesso após validação de ações e autorização.');
      setSelectedOcorrencia({
        ...selectedOcorrencia,
        status: 'encerrada',
        resolucao: resolucaoTexto || selectedOcorrencia.resolucao,
        autorizadoPor: `${userProfile?.nome} (${userProfile?.cargo})`,
        autorizadoEm: new Date().toISOString(),
      });
      setResolucaoTexto('');
      setTimeout(() => setSuccessMsg(null), 4000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-rose-400">
            Fase Detectar & Orquestrar
          </span>
          <h2 className="text-lg font-bold text-white">Gestão e Encerramento Formal de Ocorrências</h2>
          <p className="text-xs text-slate-400">
            Regra Determinística: Nenhuma ocorrência é encerrada sem resolução técnica, 100% das ações obrigatórias finalizadas e autorização por perfil com poder de gestão.
          </p>
        </div>
        <button
          onClick={() => setShowNovaModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-md transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Registrar Nova Ocorrência</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-3.5 bg-emerald-950/80 border border-emerald-600 text-emerald-200 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          {successMsg}
        </div>
      )}

      {/* Grid: List of occurrences & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Ocorrências List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg space-y-2">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider px-2 py-1">
            Ocorrências da Obra ({ocorrencias.length})
          </div>

          <div className="space-y-2 max-h-[550px] overflow-y-auto">
            {ocorrencias.map((oco) => {
              const isSelected = selectedOcorrencia?.id === oco.id;
              const acoesTotal = oco.acoesNecessarias?.length || 0;
              const acoesConcluidas = oco.acoesNecessarias?.filter((a) => a.concluida).length || 0;

              return (
                <button
                  key={oco.id}
                  onClick={() => {
                    setSelectedOcorrencia(oco);
                    setResolucaoTexto(oco.resolucao || '');
                    setErrorMsg(null);
                    setBloqueiosList([]);
                  }}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-rose-500/15 border-rose-500 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-mono text-xs font-bold text-rose-400">{oco.codigo}</span>
                    <StatusBadge status={oco.gravidade} size="sm" />
                  </div>

                  <div className="text-xs font-bold text-slate-200 line-clamp-1">{oco.titulo}</div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                    <StatusBadge status={oco.status} size="sm" />
                    <span>
                      {acoesConcluidas}/{acoesTotal} ações
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Occurrence Detail & Closure Workflow */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          {selectedOcorrencia ? (
            <div className="space-y-5">
              {/* Top details */}
              <div className="border-b border-slate-800 pb-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-rose-400">
                      {selectedOcorrencia.codigo}
                    </span>
                    <StatusBadge status={selectedOcorrencia.status} />
                    <StatusBadge status={selectedOcorrencia.gravidade} />
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Registrado em: {new Date(selectedOcorrencia.createdAt).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white mt-2">{selectedOcorrencia.titulo}</h3>
                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                  {selectedOcorrencia.descricao}
                </p>

                <div className="flex items-center gap-4 text-[11px] text-slate-400 mt-2">
                  <span>
                    Tipo: <strong className="text-slate-200 capitalize">{selectedOcorrencia.tipo}</strong>
                  </span>
                  <span>
                    Registrado por: <strong className="text-slate-200">{selectedOcorrencia.registradoPorNome}</strong>
                  </span>
                </div>
              </div>

              {/* Ações Necessárias (Obrigatórias) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckSquare className="w-4 h-4 text-amber-400" />
                    Plano de Ações Corretivas / Preventivas
                  </span>
                  <span className="text-xs text-slate-400">
                    Todas devem ser concluídas para liberar encerramento
                  </span>
                </div>

                <div className="space-y-2 mb-3">
                  {selectedOcorrencia.acoesNecessarias?.length === 0 ? (
                    <div className="p-3 text-center text-xs text-slate-500 bg-slate-950/40 rounded-lg border border-slate-800">
                      Nenhuma ação cadastrada. Adicione ações necessárias abaixo.
                    </div>
                  ) : (
                    selectedOcorrencia.acoesNecessarias?.map((acao) => (
                      <div
                        key={acao.id}
                        onClick={() => handleToggleAcao(acao.id)}
                        className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between gap-3 transition ${
                          acao.concluida
                            ? 'bg-emerald-950/20 border-emerald-800/80 text-emerald-200'
                            : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-5 h-5 rounded flex items-center justify-center shrink-0 border ${
                              acao.concluida
                                ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                                : 'border-slate-700 bg-slate-800'
                            }`}
                          >
                            {acao.concluida && <CheckCircle className="w-3.5 h-3.5" />}
                          </div>
                          <div>
                            <span className={`text-xs font-medium ${acao.concluida ? 'line-through opacity-80' : ''}`}>
                              {acao.descricao}
                            </span>
                            <div className="text-[10px] text-slate-400">
                              Responsável: <strong>{acao.responsavelNome}</strong>
                            </div>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider">
                          {acao.concluida ? 'Concluída' : 'Pendente'}
                        </span>
                      </div>
                    ))
                  )}
                </div>

                {/* Add new action */}
                {selectedOcorrencia.status !== 'encerrada' && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Descrição da ação preventiva ou corretiva..."
                      value={novaAcaoTexto}
                      onChange={(e) => setNovaAcaoTexto(e.target.value)}
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                    <input
                      type="text"
                      placeholder="Responsável"
                      value={novaAcaoResponsavel}
                      onChange={(e) => setNovaAcaoResponsavel(e.target.value)}
                      className="w-32 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                    <button
                      onClick={handleAdicionarAcao}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700"
                    >
                      Adicionar Ação
                    </button>
                  </div>
                )}
              </div>

              {/* Closure Section (Resolução & Autorização) */}
              <div className="border-t border-slate-800 pt-4 space-y-3">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-sky-400" />
                  Resolução Técnica e Autorização Formal
                </span>

                {selectedOcorrencia.status === 'encerrada' ? (
                  <div className="bg-emerald-950/40 border border-emerald-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                      <CheckCircle className="w-4 h-4" />
                      Ocorrência Encerrada e Autorizada
                    </div>
                    <p className="text-xs text-slate-300">{selectedOcorrencia.resolucao}</p>
                    <div className="text-[11px] text-slate-400 pt-1 border-t border-emerald-900/50 flex justify-between">
                      <span>Autorizado por: <strong>{selectedOcorrencia.autorizadoPor}</strong></span>
                      <span>Data: {new Date(selectedOcorrencia.autorizadoEm || '').toLocaleString('pt-BR')}</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <textarea
                      rows={3}
                      placeholder="Descreva a resolução técnica formal que neutralizou o risco/problema..."
                      value={resolucaoTexto}
                      onChange={(e) => setResolucaoTexto(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />

                    {errorMsg && (
                      <div className="p-3 bg-red-950/80 border border-red-600 text-red-200 text-xs rounded-xl space-y-1">
                        <div className="font-bold flex items-center gap-1.5">
                          <AlertOctagon className="w-4 h-4 text-red-400 shrink-0" />
                          Bloqueio de Regra de Negócio:
                        </div>
                        <p>{errorMsg}</p>
                        {bloqueiosList.length > 0 && (
                          <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px] text-red-300">
                            {bloqueiosList.map((b, i) => (
                              <li key={i}>{b}</li>
                            ))}
                          </ul>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Perfil atual: <strong className="text-amber-400">{activeRole}</strong>
                        {activeRole === 'campo' && (
                          <span className="text-red-400 ml-1">(Sem poder de encerramento)</span>
                        )}
                      </span>

                      <button
                        onClick={handleEncerrar}
                        className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-lg transition active:scale-95 flex items-center gap-2"
                      >
                        <Shield className="w-4 h-4" />
                        <span>Validar & Encerrar Ocorrência</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500">
              Selecione uma ocorrência para analisar e orquestrar resoluções.
            </div>
          )}
        </div>
      </div>

      {/* Modal Nova Ocorrencia */}
      {showNovaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              Registrar Ocorrência na Obra
            </h3>

            <form onSubmit={handleCriarOcorrencia} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Título da Ocorrência</label>
                <input
                  type="text"
                  required
                  value={novoTitulo}
                  onChange={(e) => setNovoTitulo(e.target.value)}
                  placeholder="Ex: Falha no escoramento do 3º pavimento"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Tipo de Ocorrência</label>
                  <select
                    value={novoTipo}
                    onChange={(e) => setNovoTipo(e.target.value as TipoOcorrencia)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                    <option value="seguranca">Segurança (NR-18)</option>
                    <option value="qualidade">Qualidade Construtiva</option>
                    <option value="material">Insumo / Material</option>
                    <option value="projeto">Divergência de Projeto</option>
                    <option value="clima">Clima / Chuva Intensa</option>
                    <option value="maquinario">Equipamento / Quebra</option>
                    <option value="interferencia">Interferência de Frente</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Gravidade</label>
                  <select
                    value={novaGravidade}
                    onChange={(e) => setNovaGravidade(e.target.value as GravidadeOcorrencia)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                    <option value="baixa">Baixa</option>
                    <option value="media">Média</option>
                    <option value="alta">Alta</option>
                    <option value="critica">CRÍTICA (Bloqueia Conclusão)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Descrição Detalhada do Desvio</label>
                <textarea
                  rows={4}
                  required
                  value={novaDescricao}
                  onChange={(e) => setNovaDescricao(e.target.value)}
                  placeholder="Descreva exatamente o local, a não conformidade observada e o risco potencial..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNovaModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold shadow-md"
                >
                  Registrar Ocorrência
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
