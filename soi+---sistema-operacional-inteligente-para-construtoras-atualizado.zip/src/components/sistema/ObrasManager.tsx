import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Calendar,
  User,
  MapPin,
  CheckCircle,
  AlertOctagon,
  ArrowRight,
  ShieldAlert,
  Award,
} from 'lucide-react';
import {
  Atividade,
  Etapa,
  Obra,
  Ocorrencia,
  Pendencia,
  StatusObra,
} from '../../domain/types';
import { StatusBadge } from '../common/StatusBadge';
import { useAuth } from '../../firebase/auth';

interface ObrasManagerProps {
  obras: Obra[];
  etapas: Etapa[];
  atividades: Atividade[];
  ocorrencias: Ocorrencia[];
  pendencias: Pendencia[];
  onSelectObra: (obra: Obra) => void;
  onSalvarObra: (obra: Obra) => Promise<void>;
  onAtualizarStatusObra: (obra: Obra, novoStatus: StatusObra) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
}

export const ObrasManager: React.FC<ObrasManagerProps> = ({
  obras,
  etapas,
  atividades,
  ocorrencias,
  pendencias,
  onSelectObra,
  onSalvarObra,
  onAtualizarStatusObra,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [showNovaModal, setShowNovaModal] = useState(false);
  const [bloqueioFeedback, setBloqueioFeedback] = useState<{ obraId: string; msg: string; bloqueios?: string[] } | null>(null);

  // Form state
  const [codigo, setCodigo] = useState('');
  const [nome, setNome] = useState('');
  const [endereco, setEndereco] = useState('');
  const [cidade, setCidade] = useState('São Paulo - SP');
  const [dataInicio, setDataInicio] = useState(new Date().toISOString().split('T')[0]);
  const [dataPrevisaoFim, setDataPrevisaoFim] = useState('');
  const [descricao, setDescricao] = useState('');

  const handleCriarObra = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    const novaObra: Obra = {
      id: 'obra_' + Date.now(),
      codigo: codigo.trim() || `OBR-${String(obras.length + 1).padStart(3, '0')}`,
      nome: nome.trim(),
      endereco: endereco.trim(),
      cidade: cidade.trim(),
      status: 'planejamento',
      dataInicio,
      dataPrevisaoFim: dataPrevisaoFim || '2027-12-31',
      responsavelUid: userProfile.uid,
      responsavelNome: userProfile.nome,
      descricao: descricao.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await onSalvarObra(novaObra);
    setShowNovaModal(false);
    setCodigo('');
    setNome('');
    setEndereco('');
    setDescricao('');
  };

  const handleTentarConcluir = async (obra: Obra) => {
    setBloqueioFeedback(null);
    const res = await onAtualizarStatusObra(obra, 'concluida');
    if (!res.sucesso) {
      setBloqueioFeedback({
        obraId: obra.id,
        msg: res.erro || 'Falha ao concluir obra.',
        bloqueios: res.bloqueios,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Portfólio Operacional da Construtora
          </span>
          <h2 className="text-lg font-bold text-white">Obras e Empreendimentos Ativos</h2>
          <p className="text-xs text-slate-400">
            Regra Determinística de Fechamento: Nenhuma obra pode ser concluída enquanto existirem pendências obrigatórias ou ocorrências críticas não encerradas.
          </p>
        </div>
        <button
          onClick={() => setShowNovaModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold shadow-md transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Nova Obra</span>
        </button>
      </div>

      {/* Grid of Obras */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {obras.map((obra) => {
          const ativsObra = atividades.filter((a) => a.obraId === obra.id);
          const ocosCriticas = ocorrencias.filter(
            (o) => o.obraId === obra.id && o.gravidade === 'critica' && o.status !== 'encerrada'
          );
          const pendsObrigatorias = pendencias.filter(
            (p) => p.obraId === obra.id && p.obrigatoria && p.status !== 'concluida'
          );
          const feedback = bloqueioFeedback?.obraId === obra.id ? bloqueioFeedback : null;

          const totalAtivs = ativsObra.length;
          const ativsConcluidas = ativsObra.filter((a) => a.status === 'concluida').length;
          const percentualGeral = totalAtivs > 0 ? Math.round((ativsConcluidas / totalAtivs) * 100) : 0;

          return (
            <div
              key={obra.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-amber-400 px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                      {obra.codigo}
                    </span>
                    <StatusBadge status={obra.status} />
                  </div>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(obra.dataInicio).toLocaleDateString('pt-BR')} a {new Date(obra.dataPrevisaoFim).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white mb-1">{obra.nome}</h3>
                <p className="text-xs text-slate-400 flex items-center gap-1.5 mb-3">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{obra.endereco}, {obra.cidade}</span>
                </p>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-800 mb-4">
                  {obra.descricao}
                </p>

                {/* Indicators grid */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs mb-4">
                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Progresso</div>
                    <div className="text-sm font-black text-amber-400 mt-0.5">{percentualGeral}%</div>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Ocorrências Críticas</div>
                    <div className={`text-sm font-black mt-0.5 ${ocosCriticas.length > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {ocosCriticas.length}
                    </div>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Pendências Bloq.</div>
                    <div className={`text-sm font-black mt-0.5 ${pendsObrigatorias.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {pendsObrigatorias.length}
                    </div>
                  </div>
                </div>

                {/* Feedback of rule failure */}
                {feedback && (
                  <div className="p-3 bg-red-950/90 border border-red-600 rounded-xl text-red-200 text-xs mb-4 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <AlertOctagon className="w-4 h-4 text-red-400 shrink-0" />
                      Conclusão Bloqueada Deterministicamente:
                    </div>
                    <p>{feedback.msg}</p>
                    {feedback.bloqueios && (
                      <ul className="list-disc list-inside space-y-0.5 text-[11px] text-red-300 mt-1">
                        {feedback.bloqueios.map((b, idx) => (
                          <li key={idx}>{b}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  Resp: <strong className="text-slate-300">{obra.responsavelNome}</strong>
                </span>

                <div className="flex items-center gap-2">
                  {obra.status !== 'concluida' && (
                    <button
                      onClick={() => handleTentarConcluir(obra)}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-800/60 rounded-lg font-semibold flex items-center gap-1"
                      title="Validar regras e concluir obra"
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>Concluir</span>
                    </button>
                  )}

                  <button
                    onClick={() => onSelectObra(obra)}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg flex items-center gap-1 transition"
                  >
                    <span>Abrir Cronograma</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Nova Obra */}
      {showNovaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl text-slate-100">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-amber-500" />
              Cadastrar Nova Obra
            </h3>

            <form onSubmit={handleCriarObra} className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Código</label>
                  <input
                    type="text"
                    required
                    placeholder="OBR-003"
                    value={codigo}
                    onChange={(e) => setCodigo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white uppercase focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Nome do Empreendimento</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Condomínio Bosque dos Ipês"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Endereço da Obra</label>
                <input
                  type="text"
                  required
                  placeholder="Rua, número, bairro"
                  value={endereco}
                  onChange={(e) => setEndereco(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Data Início</label>
                  <input
                    type="date"
                    required
                    value={dataInicio}
                    onChange={(e) => setDataInicio(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Previsão de Término</label>
                  <input
                    type="date"
                    required
                    value={dataPrevisaoFim}
                    onChange={(e) => setDataPrevisaoFim(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Descrição e Escopo Construtivo</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Características da fundação, estrutura, número de pavimentos e tipologia..."
                  value={descricao}
                  onChange={(e) => setDescricao(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNovaModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold"
                >
                  Salvar Obra
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
