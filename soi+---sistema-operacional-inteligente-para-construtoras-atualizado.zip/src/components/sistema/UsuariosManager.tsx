import React, { useEffect, useState } from 'react';
import {
  Users,
  ShieldCheck,
  Clock,
  UserCheck,
  UserX,
  AlertTriangle,
  RefreshCw,
  Search,
  Shield,
  CheckCircle,
} from 'lucide-react';
import { UserProfile, UserRole } from '../../domain/types';
import { FirestoreService } from '../../services/firestoreService';
import { useAuth } from '../../firebase/auth';
import { DEMO_USERS } from '../../domain/demoData';

export const UsuariosManager: React.FC = () => {
  const { userProfile, isDemoMode } = useAuth();
  const [usuarios, setUsuarios] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [processandoUid, setProcessandoUid] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ tipo: 'sucesso' | 'erro'; texto: string } | null>(null);

  const carregarUsuarios = async () => {
    if (!userProfile) return;
    setLoading(true);
    setFeedback(null);
    try {
      if (isDemoMode) {
        setUsuarios(DEMO_USERS);
      } else {
        const list = await FirestoreService.listarUsuarios(userProfile);
        setUsuarios(list.length > 0 ? list : [userProfile]);
      }
    } catch (e: any) {
      setFeedback({ tipo: 'erro', texto: e.message || 'Erro ao carregar colaboradores' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarUsuarios();
  }, [userProfile, isDemoMode]);

  const handleAlterarStatus = async (user: UserProfile, novoStatus: 'ativo' | 'inativo' | 'pendente') => {
    if (!userProfile) return;
    setProcessandoUid(user.uid);
    setFeedback(null);
    try {
      if (isDemoMode) {
        setUsuarios((prev) =>
          prev.map((u) => (u.uid === user.uid ? { ...u, status: novoStatus } : u))
        );
        setFeedback({
          tipo: 'sucesso',
          texto: `[DEMO] Status de "${user.nome}" alterado para ${novoStatus.toUpperCase()}.`,
        });
      } else {
        await FirestoreService.atualizarStatusUsuario(user, novoStatus, userProfile);
        setUsuarios((prev) =>
          prev.map((u) => (u.uid === user.uid ? { ...u, status: novoStatus } : u))
        );
        setFeedback({
          tipo: 'sucesso',
          texto: `Colaborador "${user.nome}" agora está ${novoStatus.toUpperCase()} no sistema!`,
        });
      }
    } catch (e: any) {
      setFeedback({ tipo: 'erro', texto: e.message || 'Falha ao alterar status do usuário.' });
    } finally {
      setProcessandoUid(null);
    }
  };

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'gestao':
        return 'Gestão Executiva';
      case 'administracao':
        return 'Administração Central';
      case 'responsavel_obra':
        return 'Responsável de Obra';
      case 'encarregado_mestre':
        return 'Mestre / Encarregado';
      case 'campo':
        return 'Equipe de Campo';
      default:
        return role;
    }
  };

  const pendentesCount = usuarios.filter((u) => u.status === 'pendente').length;
  const ativosCount = usuarios.filter((u) => u.status === 'ativo').length;

  const filtrados = usuarios.filter(
    (u) =>
      u.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.cargo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Banner with Security Rules Details */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Controle de Acesso Operacional (7.1)
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
              {pendentesCount} Pendente{pendentesCount !== 1 ? 's' : ''}
            </span>
          </div>
          <h2 className="text-lg font-black text-white mt-1">Gestão de Colaboradores e Aprovações</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Novas contas registradas no sistema entram compulsoriamente com o status{' '}
            <strong className="text-amber-400">PENDENTE</strong>. Somente membros de{' '}
            <strong className="text-white">Gestão</strong> ou <strong className="text-white">Administração</strong> possuem
            permissão no Firestore para homologar e ativar novos acessos operacionais.
          </p>
        </div>

        <button
          onClick={carregarUsuarios}
          disabled={loading}
          className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition self-start md:self-auto shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${loading ? 'animate-spin' : ''}`} />
          <span>Atualizar Lista</span>
        </button>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 ${
            feedback.tipo === 'sucesso'
              ? 'bg-emerald-950/70 border-emerald-800 text-emerald-200'
              : 'bg-rose-950/70 border-rose-800 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.tipo === 'sucesso' ? (
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{feedback.texto}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-[11px] underline opacity-80 hover:opacity-100"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Aguardando Aprovação
            </div>
            <div className="text-xl font-black text-amber-400 mt-0.5">{pendentesCount}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Usuários Ativos
            </div>
            <div className="text-xl font-black text-emerald-400 mt-0.5">{ativosCount}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Total de Contas
            </div>
            <div className="text-xl font-black text-white mt-0.5">{usuarios.length}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300">
            <Users className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5">
        <Search className="w-4 h-4 text-slate-500 mr-2 shrink-0" />
        <input
          type="text"
          placeholder="Buscar colaborador por nome, e-mail ou cargo..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-transparent text-xs text-white placeholder-slate-500 w-full focus:outline-none"
        />
      </div>

      {/* Users Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/70 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Colaborador</th>
                <th className="py-3 px-4">Perfil / Cargo</th>
                <th className="py-3 px-4">Status no Firestore</th>
                <th className="py-3 px-4 text-right">Ação de Segurança</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filtrados.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-500">
                    Nenhum colaborador encontrado para a busca informada.
                  </td>
                </tr>
              ) : (
                filtrados.map((u) => {
                  const isSelf = u.uid === userProfile?.uid;
                  const isProcessing = processandoUid === u.uid;

                  return (
                    <tr
                      key={u.uid}
                      className={`hover:bg-slate-800/40 transition ${
                        u.status === 'pendente' ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>{u.nome}</span>
                          {isSelf && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
                              Você
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-200">{getRoleLabel(u.role)}</div>
                        <div className="text-[11px] text-slate-400">{u.cargo}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        {u.status === 'ativo' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            ATIVO
                          </span>
                        )}
                        {u.status === 'pendente' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 animate-pulse">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                            PENDENTE
                          </span>
                        )}
                        {u.status === 'inativo' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                            INATIVO
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        {isSelf ? (
                          <span className="text-[10px] text-slate-500 italic">Sessão Atual</span>
                        ) : u.status === 'pendente' ? (
                          <button
                            onClick={() => handleAlterarStatus(u, 'ativo')}
                            disabled={isProcessing}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-md transition disabled:opacity-50"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{isProcessing ? 'Aprovando...' : 'Aprovar e Ativar'}</span>
                          </button>
                        ) : u.status === 'ativo' ? (
                          <button
                            onClick={() => handleAlterarStatus(u, 'inativo')}
                            disabled={isProcessing}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-rose-950 hover:text-rose-300 hover:border-rose-800 text-slate-400 rounded-lg text-[11px] font-medium border border-slate-700 transition disabled:opacity-50"
                          >
                            <UserX className="w-3 h-3" />
                            <span>Inativar</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleAlterarStatus(u, 'ativo')}
                            disabled={isProcessing}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-emerald-950 hover:text-emerald-300 hover:border-emerald-800 text-slate-400 rounded-lg text-[11px] font-medium border border-slate-700 transition disabled:opacity-50"
                          >
                            <UserCheck className="w-3 h-3" />
                            <span>Reativar</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
