import React, { useState } from 'react';
import {
  HardHat,
  Play,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Users,
  CheckCircle2,
  Clock,
  MapPin,
  ChevronRight,
  Sun,
  Flame,
  Check,
  Smartphone,
} from 'lucide-react';
import {
  Atividade,
  CriterioProntidao,
  Execucao,
  Obra,
  Ocorrencia,
  StatusAtividade,
} from '../../domain/types';
import { StatusBadge } from '../common/StatusBadge';
import { ApontamentoExecucaoModal } from './ApontamentoExecucaoModal';
import { RegistroOcorrenciaFieldModal } from './RegistroOcorrenciaFieldModal';
import { calcularStatusProntidao } from '../../domain/rules';
import { useAuth } from '../../firebase/auth';

interface AppFieldHomeProps {
  obra: Obra;
  obras: Obra[];
  atividades: Atividade[];
  execucoes: Execucao[];
  ocorrencias: Ocorrencia[];
  onSelectObra: (obra: Obra) => void;
  onSalvarExecucao: (exec: Execucao) => Promise<void>;
  onSalvarProntidao: (ativ: Atividade, criterios: CriterioProntidao[]) => Promise<void>;
  onSalvarOcorrencia: (oco: Ocorrencia) => Promise<void>;
  onAtualizarStatusAtividade: (ativ: Atividade, status: StatusAtividade) => Promise<{ sucesso: boolean; erro?: string; bloqueios?: string[] }>;
}

export const AppFieldHome: React.FC<AppFieldHomeProps> = ({
  obra,
  obras,
  atividades,
  execucoes,
  ocorrencias,
  onSelectObra,
  onSalvarExecucao,
  onSalvarProntidao,
  onSalvarOcorrencia,
  onAtualizarStatusAtividade,
}) => {
  const { userProfile, activeRole } = useAuth();
  const [selectedAtividade, setSelectedAtividade] = useState<Atividade | null>(null);
  const [showApontamentoModal, setShowApontamentoModal] = useState(false);
  const [showOcorrenciaModal, setShowOcorrenciaModal] = useState(false);
  const [filtroStatus, setFiltroStatus] = useState<'todas' | 'liberadas' | 'execucao'>('todas');

  // Atividades do canteiro
  const frentes = atividades.filter((a) => {
    if (filtroStatus === 'liberadas') return a.status === 'liberada';
    if (filtroStatus === 'execucao') return a.status === 'em_execucao';
    return a.status !== 'planejada';
  });

  const handleOpenApontamento = (ativ: Atividade) => {
    setSelectedAtividade(ativ);
    setShowApontamentoModal(true);
  };

  const handleOpenOcorrencia = (ativ?: Atividade) => {
    setSelectedAtividade(ativ || null);
    setShowOcorrenciaModal(true);
  };

  const handleToggleProntidaoField = async (ativ: Atividade, critId: string) => {
    if (!userProfile) return;
    const novosCriterios = ativ.criteriosProntidao.map((c) => {
      if (c.id === critId) {
        const atendido = !c.atendido;
        return {
          ...c,
          atendido,
          verificadoPor: atendido ? `${userProfile.nome} (Campo)` : undefined,
          verificadoEm: atendido ? new Date().toISOString() : undefined,
        };
      }
      return c;
    });

    await onSalvarProntidao(ativ, novosCriterios);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-4 space-y-4 pb-24">
      {/* Mobile Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500 text-slate-950">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                SOI+ Canteiro de Obras (PWA)
              </div>
              <div className="text-sm font-bold text-white flex items-center gap-1">
                <span>{userProfile?.nome.split(' ')[0]}</span>
                <span className="text-xs font-normal text-slate-400">({activeRole})</span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-[10px] text-slate-400 flex items-center justify-end gap-1">
              <Sun className="w-3 h-3 text-amber-400" />
              <span>{new Date().toLocaleDateString('pt-BR', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
            </div>
            <div className="text-[11px] font-bold text-emerald-400">
              {navigator.onLine ? 'Online' : 'Offline (Local)'}
            </div>
          </div>
        </div>

        {/* Obra selector dropdown */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
          <span className="text-xs text-slate-400 font-semibold">Canteiro:</span>
          <select
            value={obra.id}
            onChange={(e) => {
              const ob = obras.find((o) => o.id === e.target.value);
              if (ob) onSelectObra(ob);
            }}
            className="flex-1 bg-slate-950 border border-slate-700 text-xs text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-500 font-bold"
          >
            {obras.map((o) => (
              <option key={o.id} value={o.id}>
                {o.nome} ({o.codigo})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Field Action Buttons */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => {
            const frenteAtiva = frentes.find((f) => f.status === 'em_execucao' || f.status === 'liberada') || frentes[0];
            if (frenteAtiva) handleOpenApontamento(frenteAtiva);
          }}
          className="p-3 bg-gradient-to-br from-amber-500 to-amber-600 active:scale-95 text-slate-950 font-bold rounded-xl shadow-lg flex items-center gap-2.5 transition"
        >
          <Play className="w-5 h-5 shrink-0" />
          <div className="text-left">
            <div className="text-xs leading-tight font-black">Apontar Diário</div>
            <div className="text-[10px] text-slate-900 font-medium">Avanço & Efetivo</div>
          </div>
        </button>

        <button
          onClick={() => handleOpenOcorrencia()}
          className="p-3 bg-slate-800 hover:bg-slate-750 active:scale-95 border border-slate-700 text-white font-bold rounded-xl shadow-md flex items-center gap-2.5 transition"
        >
          <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
          <div className="text-left">
            <div className="text-xs leading-tight">Alerta de Campo</div>
            <div className="text-[10px] text-slate-400 font-medium">Relatar Ocorrência</div>
          </div>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs">
        <button
          onClick={() => setFiltroStatus('todas')}
          className={`flex-1 py-1.5 text-center font-bold rounded-lg transition ${
            filtroStatus === 'todas'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Todas ({atividades.length})
        </button>
        <button
          onClick={() => setFiltroStatus('liberadas')}
          className={`flex-1 py-1.5 text-center font-bold rounded-lg transition ${
            filtroStatus === 'liberadas'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Liberadas ({atividades.filter((a) => a.status === 'liberada').length})
        </button>
        <button
          onClick={() => setFiltroStatus('execucao')}
          className={`flex-1 py-1.5 text-center font-bold rounded-lg transition ${
            filtroStatus === 'execucao'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Em Execução ({atividades.filter((a) => a.status === 'em_execucao').length})
        </button>
      </div>

      {/* Frentes de Trabalho List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs px-1">
          <span className="font-bold text-slate-300 uppercase tracking-wider">
            Frentes de Trabalho no Canteiro
          </span>
          <span className="text-slate-500">{frentes.length} frente(s)</span>
        </div>

        {frentes.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 rounded-xl border border-slate-800">
            Nenhuma frente de trabalho liberada no momento. Verifique a prontidão com o responsável da obra.
          </div>
        ) : (
          frentes.map((ativ) => {
            const prontidao = calcularStatusProntidao(ativ);
            const isEmExecucao = ativ.status === 'em_execucao';

            return (
              <div
                key={ativ.id}
                className={`p-4 rounded-2xl border shadow-md space-y-3 transition ${
                  isEmExecucao
                    ? 'bg-slate-900 border-amber-500/70'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <StatusBadge status={ativ.status} size="sm" />
                      <span className="text-[10px] text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-amber-400" />
                        {ativ.localizacao}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white">{ativ.nome}</h3>
                  </div>

                  <span className="text-sm font-mono font-black text-amber-400 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">
                    {ativ.percentualAvanco || 0}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all"
                    style={{ width: `${ativ.percentualAvanco || 0}%` }}
                  />
                </div>

                {/* Touch-Friendly Prontidão Quick Checks */}
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      Prontidão de Campo:
                    </span>
                    <span
                      className={`font-semibold ${
                        prontidao.todosObrigatoriosAtendidos ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {prontidao.atendidosObrigatorios}/{prontidao.totalObrigatorios} checados
                    </span>
                  </div>

                  <div className="space-y-1.5 pt-1">
                    {ativ.criteriosProntidao?.slice(0, 3).map((crit) => (
                      <div
                        key={crit.id}
                        onClick={() => handleToggleProntidaoField(ativ, crit.id)}
                        className={`flex items-center justify-between p-2 rounded-lg border text-xs cursor-pointer active:scale-98 transition ${
                          crit.atendido
                            ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span className="truncate pr-2">{crit.titulo}</span>
                        <div
                          className={`w-4 h-4 rounded flex items-center justify-center shrink-0 border ${
                            crit.atendido
                              ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                              : 'border-slate-700 bg-slate-800'
                          }`}
                        >
                          {crit.atendido && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions for this activity */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleOpenApontamento(ativ)}
                    className="flex-1 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-xs font-bold rounded-xl shadow-md transition flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Apontar Avanço</span>
                  </button>

                  <button
                    onClick={() => handleOpenOcorrencia(ativ)}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-rose-400 border border-slate-700 text-xs font-bold rounded-xl active:scale-95"
                    title="Relatar ocorrência nesta frente"
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Recent Field Apontamentos List */}
      <div className="space-y-3 pt-4">
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider px-1">
          Últimos Apontamentos no Canteiro
        </div>

        <div className="space-y-2">
          {execucoes.slice(0, 4).map((ex) => (
            <div
              key={ex.id}
              className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5 text-xs"
            >
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-amber-400 uppercase tracking-wider">
                  {ex.tipo} ({ex.percentualAvanco}%)
                </span>
                <span className="text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(ex.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <p className="text-slate-300 text-xs">{ex.observacao}</p>
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
                <span>Por: <strong className="text-slate-300">{ex.registradoPorNome}</strong></span>
                <span>Efetivo: <strong className="text-emerald-400">{ex.efetivoPresente} operários</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {selectedAtividade && (
        <ApontamentoExecucaoModal
          isOpen={showApontamentoModal}
          onClose={() => setShowApontamentoModal(false)}
          atividade={selectedAtividade}
          onSalvarExecucao={onSalvarExecucao}
        />
      )}

      <RegistroOcorrenciaFieldModal
        isOpen={showOcorrenciaModal}
        onClose={() => setShowOcorrenciaModal(false)}
        obraId={obra.id}
        atividadeSelecionada={selectedAtividade || undefined}
        onSalvarOcorrencia={onSalvarOcorrencia}
      />
    </div>
  );
};
