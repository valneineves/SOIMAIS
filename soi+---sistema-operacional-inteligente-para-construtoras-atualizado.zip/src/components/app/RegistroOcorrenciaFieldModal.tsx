import React, { useState } from 'react';
import { AlertTriangle, X, ShieldAlert, Camera, MapPin } from 'lucide-react';
import { Atividade, GravidadeOcorrencia, Ocorrencia, TipoOcorrencia } from '../../domain/types';
import { useAuth } from '../../firebase/auth';

interface RegistroOcorrenciaFieldModalProps {
  isOpen: boolean;
  onClose: () => void;
  obraId: string;
  atividadeSelecionada?: Atividade;
  onSalvarOcorrencia: (oco: Ocorrencia) => Promise<void>;
}

export const RegistroOcorrenciaFieldModal: React.FC<RegistroOcorrenciaFieldModalProps> = ({
  isOpen,
  onClose,
  obraId,
  atividadeSelecionada,
  onSalvarOcorrencia,
}) => {
  const { userProfile } = useAuth();
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [tipo, setTipo] = useState<TipoOcorrencia>('seguranca');
  const [gravidade, setGravidade] = useState<GravidadeOcorrencia>('media');
  const [saving, setSaving] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    setSaving(true);
    try {
      const codigo = `OCO-${Date.now().toString().slice(-4)}-CAMPO`;
      const nova: Ocorrencia = {
        id: 'oco_campo_' + Date.now(),
        obraId,
        atividadeId: atividadeSelecionada?.id,
        etapaId: atividadeSelecionada?.etapaId,
        codigo,
        titulo: titulo.trim(),
        descricao: descricao.trim(),
        tipo,
        gravidade,
        status: 'aberta',
        acoesNecessarias: [],
        registradoPorUid: userProfile.uid,
        registradoPorNome: `${userProfile.nome} (Campo)`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSalvarOcorrencia(nova);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 p-0 sm:p-4 backdrop-blur-xs">
      <div className="w-full sm:max-w-md bg-slate-900 border-t sm:border border-slate-700 rounded-t-2xl sm:rounded-2xl p-5 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                Alerta de Canteiro
              </span>
              <h3 className="text-sm font-bold text-white">Relatar Ocorrência / Impeditivo</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Título Rápido do Problema
            </label>
            <input
              type="text"
              required
              placeholder="Ex: Falta de tela guarda-corpo no 4º pav."
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Categoria</label>
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value as TipoOcorrencia)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
              >
                <option value="seguranca">Segurança (NR-18)</option>
                <option value="qualidade">Qualidade Construtiva</option>
                <option value="material">Falta de Insumo</option>
                <option value="maquinario">Quebra de Equipamento</option>
                <option value="clima">Paralisação por Chuva</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Gravidade</label>
              <select
                value={gravidade}
                onChange={(e) => setGravidade(e.target.value as GravidadeOcorrencia)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
              >
                <option value="baixa">Baixa</option>
                <option value="media">Média</option>
                <option value="alta">Alta</option>
                <option value="critica">CRÍTICA (Bloqueia Frente)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Descrição do Risco / Impeditivo
            </label>
            <textarea
              rows={3}
              required
              placeholder="O que aconteceu? Quais operários ou frentes estão paralisadas?"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {atividadeSelecionada && (
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                Vinculada à frente: <strong className="text-slate-200">{atividadeSelecionada.nome}</strong>
              </span>
            </div>
          )}

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
            >
              Voltar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="w-2/3 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-lg transition active:scale-95"
            >
              {saving ? 'Registrando...' : 'Emitir Ocorrência'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
