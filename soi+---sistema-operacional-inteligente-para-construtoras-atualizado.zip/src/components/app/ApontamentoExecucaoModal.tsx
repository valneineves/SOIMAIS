import React, { useState } from 'react';
import {
  Play,
  X,
  Users,
  Sun,
  Cloud,
  CloudRain,
  CheckCircle,
  Clock,
  Shield,
} from 'lucide-react';
import { Atividade, Execucao, TipoExecucao } from '../../domain/types';
import { useAuth } from '../../firebase/auth';

interface ApontamentoExecucaoModalProps {
  isOpen: boolean;
  onClose: () => void;
  atividade: Atividade;
  onSalvarExecucao: (exec: Execucao) => Promise<void>;
}

export const ApontamentoExecucaoModal: React.FC<ApontamentoExecucaoModalProps> = ({
  isOpen,
  onClose,
  atividade,
  onSalvarExecucao,
}) => {
  const { userProfile } = useAuth();
  const [tipo, setTipo] = useState<TipoExecucao>('avanco');
  const [percentual, setPercentual] = useState<number>(atividade.percentualAvanco || 50);
  const [efetivo, setEfetivo] = useState<number>(8);
  const [clima, setClima] = useState<'ensolarado' | 'nublado' | 'chuvoso' | 'chuva_intensa' | 'estavel'>('ensolarado');
  const [observacao, setObservacao] = useState('');
  const [saving, setSaving] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    setSaving(true);
    try {
      const novaExec: Execucao = {
        id: 'exec_' + Date.now(),
        obraId: atividade.obraId,
        etapaId: atividade.etapaId,
        atividadeId: atividade.id,
        tipo,
        percentualAvanco: percentual,
        observacao: observacao.trim() || `Apontamento de ${tipo} realizado no canteiro.`,
        clima,
        efetivoPresente: Number(efetivo) || 1,
        registradoPorUid: userProfile.uid,
        registradoPorNome: userProfile.nome,
        offlineSync: !navigator.onLine,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSalvarExecucao(novaExec);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 p-0 sm:p-4 backdrop-blur-xs">
      <div className="w-full sm:max-w-md bg-slate-900 border-t sm:border border-slate-700 rounded-t-2xl sm:rounded-2xl p-5 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
              Apontamento Diário de Campo
            </span>
            <h3 className="text-base font-bold text-white truncate max-w-[280px]">
              {atividade.nome}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Tipo de Apontamento */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Tipo do Apontamento
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'inicio', label: 'Início Frente' },
                { key: 'avanco', label: 'Avanço Físico' },
                { key: 'finalizacao', label: 'Conclusão' },
              ].map((item) => (
                <button
                  type="button"
                  key={item.key}
                  onClick={() => {
                    setTipo(item.key as TipoExecucao);
                    if (item.key === 'finalizacao') setPercentual(100);
                  }}
                  className={`py-2 px-2 text-xs font-bold rounded-xl border text-center transition ${
                    tipo === item.key
                      ? 'bg-amber-500 border-amber-400 text-slate-950 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* % Avanço slider */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-300">Avanço Físico Estimado</span>
              <span className="font-mono text-base font-black text-amber-400">{percentual}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={percentual}
              onChange={(e) => setPercentual(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0%</span>
              <span>25%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100%</span>
            </div>
          </div>

          {/* Efetivo Presente & Clima */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Efetivo no Local
              </label>
              <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2">
                <Users className="w-4 h-4 text-emerald-400 shrink-0" />
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={efetivo}
                  onChange={(e) => setEfetivo(Number(e.target.value))}
                  className="w-full bg-transparent text-xs text-white focus:outline-none"
                />
                <span className="text-[10px] text-slate-500">op.</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Condição do Clima
              </label>
              <select
                value={clima}
                onChange={(e) => setClima(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
              >
                <option value="ensolarado">Ensolarado</option>
                <option value="nublado">Nublado</option>
                <option value="chuvoso">Chuvoso</option>
                <option value="chuva_intensa">Chuva Intensa</option>
              </select>
            </div>
          </div>

          {/* Observações de Campo */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Diário de Campo & Observações
            </label>
            <textarea
              rows={3}
              value={observacao}
              onChange={(e) => setObservacao(e.target.value)}
              placeholder="Ex: Concretados 3 pilares. Insumo entregue conforme programado..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="w-2/3 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold shadow-lg transition active:scale-95"
            >
              {saving ? 'Registrando...' : 'Confirmar Apontamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
