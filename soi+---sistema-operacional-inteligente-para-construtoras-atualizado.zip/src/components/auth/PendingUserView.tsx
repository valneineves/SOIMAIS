import React, { useState } from 'react';
import { Clock, ShieldAlert, LogOut, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { UserProfile } from '../../domain/types';

export const PendingUserView: React.FC = () => {
  const { logout, userProfile, currentUser } = useAuth();
  const [checking, setChecking] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const checkStatus = async () => {
    if (!currentUser) return;
    setChecking(true);
    setMsg(null);
    try {
      const snap = await getDoc(doc(db, 'users', currentUser.uid));
      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        if (data.status === 'ativo') {
          setMsg('Conta APROVADA! Atualizando aplicação...');
          setTimeout(() => window.location.reload(), 1500);
          return;
        }
      }
      setMsg('Seu cadastro continua com status PENDENTE de aprovação.');
      setTimeout(() => setMsg(null), 4000);
    } catch {
      setMsg('Erro ao consultar status no servidor.');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 text-slate-100">
      <div className="w-full max-w-md bg-slate-900 border border-amber-600/70 rounded-2xl p-6 shadow-2xl text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-400 mx-auto flex items-center justify-center">
          <Clock className="w-8 h-8 animate-pulse" />
        </div>

        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
            Aprovação Obrigatória
          </span>
          <h2 className="text-lg font-black text-white mt-2">Cadastro Pendente de Liberação</h2>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            A conta <strong className="text-white">{userProfile?.email || currentUser?.email}</strong> foi registrada no sistema, mas seu status atual é <span className="text-amber-400 font-bold uppercase">PENDENTE</span>.
          </p>
          <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 text-[11px] text-slate-400 text-left mt-3 space-y-1.5 leading-relaxed">
            <div className="font-bold text-slate-200">Política de Segurança Operacional:</div>
            <p>1. Usuários recém-cadastrados não recebem acesso operacional automático.</p>
            <p>2. A liberação para o canteiro (/app) ou gestão (/sistema) deve ser autorizada por um gestor ou administrador.</p>
            <p>3. As regras do Firestore bloqueiam qualquer leitura ou gravação de obras enquanto o status não for ATIVO.</p>
          </div>
        </div>

        {msg && (
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-amber-300">
            {msg}
          </div>
        )}

        <div className="pt-2 flex flex-col gap-2">
          <button
            onClick={checkStatus}
            disabled={checking}
            className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
            <span>{checking ? 'Verificando...' : 'Verificar Aprovação'}</span>
          </button>

          <button
            onClick={logout}
            className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4 text-slate-400" />
            <span>Desconectar e Voltar ao Início</span>
          </button>
        </div>
      </div>
    </div>
  );
};
