import React, { useState } from 'react';
import {
  HardHat,
  Lock,
  Mail,
  User,
  Briefcase,
  AlertCircle,
  Eye,
  EyeOff,
  ShieldCheck,
  Play,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../../firebase/auth';
import { UserRole } from '../../domain/types';

export const LoginView: React.FC = () => {
  const { loginWithEmail, registerWithEmail, enterDemoMode } = useAuth();
  const [isRegister, setIsRegister] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nome, setNome] = useState('');
  const [cargo, setCargo] = useState('');
  const [role, setRole] = useState<UserRole>('responsavel_obra');

  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    try {
      if (isRegister) {
        if (password.length < 6) {
          throw new Error('A senha deve ter no mínimo 6 caracteres.');
        }
        await registerWithEmail(email, password, nome, role, cargo);
      } else {
        await loginWithEmail(email, password);
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        setErrorMsg('E-mail ou senha incorretos.');
      } else if (err.code === 'auth/user-not-found') {
        setErrorMsg('Nenhuma conta encontrada com este e-mail.');
      } else if (err.code === 'auth/email-already-in-use') {
        setErrorMsg('Este e-mail já está cadastrado no sistema.');
      } else {
        setErrorMsg(err.message || 'Falha ao autenticar.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 py-8 text-slate-100">
      <div className="w-full max-w-md space-y-6">
        {/* Brand header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 shadow-xl shadow-amber-500/20 mb-2">
            <HardHat className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white">
            SOI<span className="text-amber-400">+</span>
          </h1>
          <p className="text-xs text-slate-400">
            Sistema Operacional Inteligente para Pequenas e Médias Construtoras
          </p>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Projeto Firebase: <strong>soimais-desenvolvimento</strong></span>
          </div>
        </div>

        {/* Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          <div className="flex border-b border-slate-800 pb-2">
            <button
              onClick={() => {
                setIsRegister(false);
                setErrorMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition ${
                !isRegister
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Entrar com E-mail
            </button>
            <button
              onClick={() => {
                setIsRegister(true);
                setErrorMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition ${
                isRegister
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Primeiro Acesso / Cadastrar
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-950/80 border border-red-600 rounded-xl text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nome Completo
                  </label>
                  <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5">
                    <User className="w-4 h-4 text-slate-500 mr-2 shrink-0" />
                    <input
                      type="text"
                      required
                      placeholder="Ex: Carlos Eduardo Mendes"
                      value={nome}
                      onChange={(e) => setNome(e.target.value)}
                      className="bg-transparent text-xs text-white placeholder-slate-500 w-full focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Perfil Operacional
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserRole)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                    >
                      <option value="responsavel_obra">Responsável de Obra</option>
                      <option value="encarregado_mestre">Mestre / Encarregado</option>
                      <option value="campo">Equipe de Campo</option>
                      <option value="administracao">Administração</option>
                      <option value="gestao">Gestão Executiva</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Cargo na Construtora
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Eng. Residente"
                      value={cargo}
                      onChange={(e) => setCargo(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                E-mail Corporativo
              </label>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5">
                <Mail className="w-4 h-4 text-slate-500 mr-2 shrink-0" />
                <input
                  type="email"
                  required
                  placeholder="usuario@construtora.com.br"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-transparent text-xs text-white placeholder-slate-500 w-full focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Senha de Acesso
              </label>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5">
                <Lock className="w-4 h-4 text-slate-500 mr-2 shrink-0" />
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-transparent text-xs text-white placeholder-slate-500 w-full focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="text-slate-500 hover:text-slate-300 text-xs ml-2"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition active:scale-98 disabled:opacity-50"
            >
              {loading ? 'Processando...' : isRegister ? 'Cadastrar e Acessar' : 'Entrar no Sistema'}
            </button>
          </form>

          {/* Explicit Demonstration Mode Divider */}
          <div className="pt-4 border-t border-slate-800/80 space-y-3">
            <div className="text-center">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                Ou Avaliação em Modo Demonstração
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  Homologação Rápida
                </span>
                <span className="text-[10px] text-amber-400 font-bold uppercase bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30">
                  Dados de Teste
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Permite testar e validar o ciclo operacional determinístico, regras de prontidão e PWA de campo com dados de teste claramente identificados.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => enterDemoMode('gestao')}
                  className="py-2 px-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-bold border border-slate-700 flex items-center justify-center gap-1"
                >
                  <span>Testar Gestão</span>
                  <ArrowRight className="w-3 h-3 text-amber-400" />
                </button>
                <button
                  onClick={() => enterDemoMode('encarregado_mestre')}
                  className="py-2 px-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-bold border border-slate-700 flex items-center justify-center gap-1"
                >
                  <span>Testar Mestre/Campo</span>
                  <ArrowRight className="w-3 h-3 text-amber-400" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Security watermark */}
        <div className="text-center text-[10px] text-slate-400 space-y-1">
          <p>Autenticação estrita via Firebase Authentication com regras em Cloud Firestore.</p>
          <p className="text-slate-400">Ambiente de Operação Construtora • Região São Paulo (southamerica-east1)</p>
        </div>
      </div>
    </div>
  );
};
