import React from 'react';
import { ShieldAlert, LogOut } from 'lucide-react';
import { useAuth } from '../../firebase/auth';

export const InactiveUserView: React.FC = () => {
  const { logout, userProfile } = useAuth();

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 text-slate-100">
      <div className="w-full max-w-md bg-slate-900 border border-red-800/80 rounded-2xl p-6 shadow-2xl text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-red-950/80 border border-red-700 text-red-400 mx-auto flex items-center justify-center">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-lg font-black text-white">Acesso Bloqueado: Usuário Inativo</h2>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            O usuário <strong className="text-white">{userProfile?.email}</strong> está registrado como{' '}
            <span className="text-rose-400 font-bold uppercase">inativo</span> no cadastro da construtora.
          </p>
          <p className="text-[11px] text-slate-400 mt-2">
            Por determinação de segurança operacional, nenhum dado da obra ou de campo pode ser visualizado ou gravado por contas inativas.
          </p>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <button
            onClick={logout}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Sair e Conectar com Outra Conta</span>
          </button>
        </div>
      </div>
    </div>
  );
};
