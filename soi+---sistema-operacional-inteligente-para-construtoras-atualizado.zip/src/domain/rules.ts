/**
 * SOI+ - Motor Determinístico de Regras de Negócio e Estados
 * 
 * Invariantes Críticas:
 * 1. Toda transição de status deve ser validada no núcleo de regras.
 * 2. Nenhuma atividade pode ser liberada sem todos os critérios obrigatórios de prontidão atendidos.
 * 3. Nenhuma atividade com dependências pode ser liberada antes da conclusão das predecessoras.
 * 4. Nenhuma ocorrência pode ser encerrada sem resolução formal, ações obrigatórias 100% concluídas e confirmação autorizada por perfil gestor.
 * 5. Nenhuma obra pode ser concluída com ocorrências críticas abertas ou pendências obrigatórias abertas.
 */

import {
  Atividade,
  Etapa,
  Obra,
  Ocorrencia,
  Pendencia,
  StatusAtividade,
  StatusEtapa,
  StatusObra,
  StatusOcorrencia,
  UserRole,
  ValidationResult,
} from './types';

// ==========================================
// 1. REGRAS DE PRONTIDÃO E ATIVIDADES
// ==========================================

export function calcularStatusProntidao(atividade: Atividade): {
  todosObrigatoriosAtendidos: boolean;
  totalObrigatorios: number;
  atendidosObrigatorios: number;
  pendentes: string[];
} {
  const obrigatorios = (atividade.criteriosProntidao || []).filter((c) => c.obrigatorio);
  const atendidos = obrigatorios.filter((c) => c.atendido);
  const pendentes = obrigatorios.filter((c) => !c.atendido).map((c) => c.titulo);

  return {
    todosObrigatoriosAtendidos: obrigatorios.length === 0 || atendidos.length === obrigatorios.length,
    totalObrigatorios: obrigatorios.length,
    atendidosObrigatorios: atendidos.length,
    pendentes,
  };
}

export function validarLiberacaoAtividade(
  atividade: Atividade,
  todasAtividadesObra: Atividade[],
  usuarioRole: UserRole
): ValidationResult {
  const bloqueios: string[] = [];

  // Permissão: Apenas Gestão, Responsável de Obra ou Encarregado/Mestre autorizado
  if (usuarioRole === 'campo') {
    bloqueios.push('Perfil de Campo não possui permissão para liberar frentes de trabalho. Requer Encarregado/Mestre ou Responsável.');
  }

  // Regra Invariante: Prontidão obrigatória
  const prontidao = calcularStatusProntidao(atividade);
  if (!prontidao.todosObrigatoriosAtendidos) {
    bloqueios.push(
      `Critérios obrigatórios de prontidão pendentes (${prontidao.pendentes.length}): ${prontidao.pendentes.join(', ')}`
    );
  }

  // Regra Invariante: Atividades predecessoras dependentes
  if (atividade.dependencias && atividade.dependencias.length > 0) {
    const predecessorasNaoConcluidas = todasAtividadesObra.filter(
      (a) => atividade.dependencias.includes(a.id) && a.status !== 'concluida'
    );

    if (predecessorasNaoConcluidas.length > 0) {
      const nomes = predecessorasNaoConcluidas.map((a) => `"${a.nome}" [Status: ${a.status}]`).join(', ');
      bloqueios.push(`Dependências predecessoras não concluídas: ${nomes}`);
    }
  }

  return {
    valido: bloqueios.length === 0,
    motivo: bloqueios.length > 0 ? bloqueios[0] : undefined,
    bloqueios,
  };
}

export function validarTransicaoAtividade(
  atividade: Atividade,
  novoStatus: StatusAtividade,
  todasAtividadesObra: Atividade[],
  usuarioRole: UserRole
): ValidationResult {
  if (atividade.status === novoStatus) {
    return { valido: true };
  }

  // Tabela de transições permitidas no ciclo determinístico
  const transicoesValidas: Record<StatusAtividade, StatusAtividade[]> = {
    planejada: ['preparando', 'bloqueada'],
    preparando: ['liberada', 'planejada', 'bloqueada'],
    liberada: ['em_execucao', 'preparando', 'bloqueada', 'pausada'],
    em_execucao: ['pausada', 'concluida', 'bloqueada'],
    pausada: ['em_execucao', 'bloqueada'],
    concluida: [], // Estado terminal (apenas reabertura assistida)
    bloqueada: ['preparando', 'liberada', 'em_execucao'],
  };

  const permitidas = transicoesValidas[atividade.status] || [];
  if (!permitidas.includes(novoStatus)) {
    return {
      valido: false,
      motivo: `Transição inválida de "${atividade.status}" para "${novoStatus}". Fluxo operacional determinístico violado.`,
    };
  }

  // Transição para LIBERADA exige checklist de prontidão e dependências
  if (novoStatus === 'liberada') {
    return validarLiberacaoAtividade(atividade, todasAtividadesObra, usuarioRole);
  }

  return { valido: true };
}

// ==========================================
// 2. REGRAS DE OCORRÊNCIAS
// ==========================================

export function validarEncerramentoOcorrencia(
  ocorrencia: Ocorrencia,
  usuarioRole: UserRole,
  resolucaoTexto?: string
): ValidationResult {
  const bloqueios: string[] = [];

  // Permissão: Encerramento formal requer autoridade técnica ou gerencial
  const perfisAutorizados: UserRole[] = ['gestao', 'administracao', 'responsavel_obra'];
  if (!perfisAutorizados.includes(usuarioRole)) {
    bloqueios.push('Apenas Gestão, Administração ou Responsável de Obra podem encerrar ocorrências formalmente.');
  }

  // Invariante: Resolução obrigatória
  const resolucaoEfetiva = resolucaoTexto || ocorrencia.resolucao;
  if (!resolucaoEfetiva || resolucaoEfetiva.trim().length < 10) {
    bloqueios.push('É obrigatório descrever a resolução detalhada (mínimo de 10 caracteres) para encerrar a ocorrência.');
  }

  // Invariante: Ações obrigatórias devem estar 100% concluídas
  if (ocorrencia.acoesNecessarias && ocorrencia.acoesNecessarias.length > 0) {
    const acoesAbertas = ocorrencia.acoesNecessarias.filter((a) => !a.concluida);
    if (acoesAbertas.length > 0) {
      bloqueios.push(
        `Existem ${acoesAbertas.length} ações preventivas/corretivas não concluídas. Todas as ações devem ser finalizadas antes do encerramento.`
      );
    }
  }

  return {
    valido: bloqueios.length === 0,
    motivo: bloqueios.length > 0 ? bloqueios[0] : undefined,
    bloqueios,
  };
}

export function validarTransicaoOcorrencia(
  ocorrencia: Ocorrencia,
  novoStatus: StatusOcorrencia,
  usuarioRole: UserRole,
  resolucaoTexto?: string
): ValidationResult {
  if (ocorrencia.status === novoStatus) return { valido: true };

  if (novoStatus === 'encerrada') {
    return validarEncerramentoOcorrencia(ocorrencia, usuarioRole, resolucaoTexto);
  }

  return { valido: true };
}

// ==========================================
// 3. REGRAS DE CONCLUSÃO DE OBRA
// ==========================================

export function validarConclusaoObra(
  obra: Obra,
  etapas: Etapa[],
  atividades: Atividade[],
  ocorrencias: Ocorrencia[],
  pendencias: Pendencia[],
  usuarioRole: UserRole
): ValidationResult {
  const bloqueios: string[] = [];

  // Perfil autorizado
  if (usuarioRole !== 'gestao' && usuarioRole !== 'responsavel_obra') {
    bloqueios.push('Apenas a Gestão ou o Responsável Técnico da Obra podem concluir uma obra.');
  }

  // Invariante: Nenhuma ocorrência crítica aberta ou em andamento
  const ocorrenciasCriticasAbertas = ocorrencias.filter(
    (o) => o.obraId === obra.id && o.gravidade === 'critica' && o.status !== 'encerrada'
  );
  if (ocorrenciasCriticasAbertas.length > 0) {
    bloqueios.push(
      `Existem ${ocorrenciasCriticasAbertas.length} ocorrência(s) CRÍTICA(S) não encerrada(s): ${ocorrenciasCriticasAbertas.map((o) => o.codigo).join(', ')}.`
    );
  }

  // Invariante: Nenhuma pendência obrigatória aberta
  const pendenciasObrigatoriasAbertas = pendencias.filter(
    (p) => p.obraId === obra.id && p.obrigatoria && p.status !== 'concluida'
  );
  if (pendenciasObrigatoriasAbertas.length > 0) {
    bloqueios.push(
      `Existem ${pendenciasObrigatoriasAbertas.length} pendência(s) obrigatória(s) em aberto: ${pendenciasObrigatoriasAbertas.map((p) => p.titulo).join(', ')}.`
    );
  }

  // Verificação de atividades não concluídas
  const atividadesNaoConcluidas = atividades.filter(
    (a) => a.obraId === obra.id && a.status !== 'concluida'
  );
  if (atividadesNaoConcluidas.length > 0) {
    bloqueios.push(`Ainda restam ${atividadesNaoConcluidas.length} atividade(s) não concluída(s) nesta obra.`);
  }

  return {
    valido: bloqueios.length === 0,
    motivo: bloqueios.length > 0 ? bloqueios[0] : undefined,
    bloqueios,
  };
}

export function validarTransicaoObra(
  obra: Obra,
  novoStatus: StatusObra,
  etapas: Etapa[],
  atividades: Atividade[],
  ocorrencias: Ocorrencia[],
  pendencias: Pendencia[],
  usuarioRole: UserRole
): ValidationResult {
  if (obra.status === novoStatus) return { valido: true };

  if (novoStatus === 'concluida') {
    return validarConclusaoObra(obra, etapas, atividades, ocorrencias, pendencias, usuarioRole);
  }

  return { valido: true };
}

// ==========================================
// 4. MAPA DE ETAPAS DO CICLO OPERACIONAL
// ==========================================

export function calcularCicloOperacionalObra(
  obra: Obra,
  atividades: Atividade[],
  ocorrencias: Ocorrencia[]
): {
  etapaAtual: 'PLANEJAR' | 'PREPARAR' | 'EXECUTAR' | 'DETECTAR' | 'ORQUESTRAR' | 'CONCLUIR';
  percentualGeral: number;
  totalAtividades: number;
  concluidas: number;
  emExecucao: number;
  emPreparacao: number;
  ocorrenciasAbertas: number;
} {
  const total = atividades.length;
  const concluidas = atividades.filter((a) => a.status === 'concluida').length;
  const emExecucao = atividades.filter((a) => a.status === 'em_execucao').length;
  const emPreparacao = atividades.filter((a) => a.status === 'preparando' || a.status === 'liberada').length;
  const ocorrenciasAbertas = ocorrencias.filter((o) => o.status !== 'encerrada').length;

  const percentualGeral = total > 0 ? Math.round((concluidas / total) * 100) : 0;

  let etapaAtual: 'PLANEJAR' | 'PREPARAR' | 'EXECUTAR' | 'DETECTAR' | 'ORQUESTRAR' | 'CONCLUIR' = 'PLANEJAR';

  if (obra.status === 'concluida') {
    etapaAtual = 'CONCLUIR';
  } else if (ocorrenciasAbertas > 0) {
    etapaAtual = 'DETECTAR';
  } else if (emExecucao > 0) {
    etapaAtual = 'EXECUTAR';
  } else if (emPreparacao > 0) {
    etapaAtual = 'PREPARAR';
  } else if (percentualGeral >= 80) {
    etapaAtual = 'ORQUESTRAR';
  } else {
    etapaAtual = 'PLANEJAR';
  }

  return {
    etapaAtual,
    percentualGeral,
    totalAtividades: total,
    concluidas,
    emExecucao,
    emPreparacao,
    ocorrenciasAbertas,
  };
}
