/**
 * SOI+ - Sistema Operacional Inteligente para Construtoras
 * Definições de Tipos do Domínio Operacional
 */

export type UserRole =
  | 'gestao'
  | 'administracao'
  | 'responsavel_obra'
  | 'encarregado_mestre'
  | 'campo';

export interface UserProfile {
  uid: string;
  nome: string;
  email: string;
  role: UserRole;
  cargo: string;
  telefone?: string;
  status: 'ativo' | 'inativo' | 'pendente';
  createdAt?: string;
  updatedAt?: string;
}

export type CicloOperacional =
  | 'PLANEJAR'
  | 'PREPARAR'
  | 'EXECUTAR'
  | 'DETECTAR'
  | 'ORQUESTRAR'
  | 'CONCLUIR';

export type StatusObra =
  | 'planejamento'
  | 'preparacao'
  | 'em_execucao'
  | 'em_conclusao'
  | 'concluida'
  | 'suspensa';

export interface Obra {
  id: string;
  codigo: string;
  nome: string;
  endereco: string;
  cidade: string;
  status: StatusObra;
  dataInicio: string;
  dataPrevisaoFim: string;
  responsavelUid: string;
  responsavelNome: string;
  membrosUids?: string[];
  descricao: string;
  createdAt: string;
  updatedAt: string;
}

export type StatusEtapa =
  | 'planejada'
  | 'pronta'
  | 'em_andamento'
  | 'concluida'
  | 'bloqueada';

export interface Etapa {
  id: string;
  obraId: string;
  ordem: number;
  nome: string;
  status: StatusEtapa;
  dataInicio: string;
  dataPrevisaoFim: string;
  createdAt: string;
  updatedAt: string;
}

export type StatusAtividade =
  | 'planejada'
  | 'preparando'
  | 'liberada'
  | 'em_execucao'
  | 'pausada'
  | 'concluida'
  | 'bloqueada';

export type TipoCriterioProntidao =
  | 'projeto'
  | 'material'
  | 'mao_de_obra'
  | 'equipamento'
  | 'seguranca'
  | 'qualidade'
  | 'clima'
  | 'liberacao';

export interface CriterioProntidao {
  id: string;
  titulo: string;
  tipo: TipoCriterioProntidao;
  obrigatorio: boolean;
  atendido: boolean;
  verificadoPor?: string;
  verificadoEm?: string;
  notas?: string;
}

export interface Atividade {
  id: string;
  obraId: string;
  etapaId: string;
  ordem: number;
  nome: string;
  descricao: string;
  status: StatusAtividade;
  dependencias: string[]; // IDs de atividades que devem estar concluídas
  criteriosProntidao: CriterioProntidao[];
  prontidaoAtendida: boolean;
  localizacao: string;
  encarregadoId: string;
  encarregadoNome: string;
  dataInicioPrevista: string;
  dataFimPrevista: string;
  percentualAvanco?: number;
  createdAt: string;
  updatedAt: string;
}

export type TipoExecucao =
  | 'inicio'
  | 'avanco'
  | 'pausa'
  | 'retomada'
  | 'finalizacao';

export interface Execucao {
  id: string;
  obraId: string;
  etapaId: string;
  atividadeId: string;
  tipo: TipoExecucao;
  percentualAvanco: number;
  observacao: string;
  clima: 'ensolarado' | 'nublado' | 'chuvoso' | 'chuva_intensa' | 'estavel';
  efetivoPresente: number;
  registradoPorUid: string;
  registradoPorNome: string;
  offlineSync?: boolean;
  fotos?: string[];
  createdAt: string;
  updatedAt: string;
}

export type TipoOcorrencia =
  | 'seguranca'
  | 'qualidade'
  | 'material'
  | 'projeto'
  | 'clima'
  | 'maquinario'
  | 'interferencia';

export type GravidadeOcorrencia = 'baixa' | 'media' | 'alta' | 'critica';

export type StatusOcorrencia =
  | 'aberta'
  | 'em_analise'
  | 'acao_em_andamento'
  | 'resolvida'
  | 'encerrada';

export interface AcaoOcorrencia {
  id: string;
  descricao: string;
  responsavelNome: string;
  concluida: boolean;
  concluidaEm?: string;
}

export interface Ocorrencia {
  id: string;
  obraId: string;
  etapaId?: string;
  atividadeId?: string;
  codigo: string;
  titulo: string;
  descricao: string;
  tipo: TipoOcorrencia;
  gravidade: GravidadeOcorrencia;
  status: StatusOcorrencia;
  acoesNecessarias: AcaoOcorrencia[];
  resolucao?: string;
  autorizadoPor?: string;
  autorizadoEm?: string;
  registradoPorUid: string;
  registradoPorNome: string;
  createdAt: string;
  updatedAt: string;
}

export type CategoriaPendencia =
  | 'documental'
  | 'tecnica'
  | 'insumo'
  | 'fiscalizacao'
  | 'vistoria';

export type StatusPendencia = 'aberta' | 'em_tratamento' | 'concluida';

export interface Pendencia {
  id: string;
  obraId: string;
  atividadeId?: string;
  titulo: string;
  descricao: string;
  categoria: CategoriaPendencia;
  obrigatoria: boolean;
  status: StatusPendencia;
  responsavelNome: string;
  prazo: string;
  concluidaPor?: string;
  concluidaEm?: string;
  createdAt: string;
  updatedAt: string;
}

export type TipoRecurso = 'equipamento' | 'equipe' | 'material_critico';
export type DisponibilidadeRecurso =
  | 'disponivel'
  | 'em_uso'
  | 'manutencao'
  | 'indisponivel';

export interface Recurso {
  id: string;
  obraId: string;
  nome: string;
  tipo: TipoRecurso;
  quantidade: number;
  unidade: string;
  disponibilidade: DisponibilidadeRecurso;
  alocadoEmAtividadeId?: string;
  observacao?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RegistroAuditoria {
  id: string;
  entidade: 'obra' | 'etapa' | 'atividade' | 'execucao' | 'ocorrencia' | 'pendencia' | 'prontidao' | 'usuario';
  entidadeId: string;
  acao: string;
  de: string;
  para: string;
  usuarioUid: string;
  usuarioNome: string;
  detalhes: string;
  timestamp: string;
}

export interface ValidationResult {
  valido: boolean;
  motivo?: string;
  bloqueios?: string[];
}
