/**
 * SOI+ - Contexto de Autenticação Real e Perfis Operacionais
 * 
 * Regras Estritas:
 * 1. Sem sessão ativa do Firebase, userProfile é NULL (não usa fallback automático de demo).
 * 2. Novos usuários entram obrigatoriamente com status: 'pendente' e aguardam aprovação de Gestão/Adm.
 * 3. Usuários com status: 'pendente' ou 'inativo' têm o acesso bloqueado imediatamente.
 * 4. O perfil real é carregado diretamente do Cloud Firestore (/users/{uid}).
 * 5. O Modo de Demonstração é explicitamente separado e não concede autorização real no Firestore.
 */

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from './config';
import { UserProfile, UserRole } from '../domain/types';
import { DEMO_USERS } from '../domain/demoData';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  activeRole: UserRole | null;
  isInactive: boolean;
  isPending: boolean;
  isDemoMode: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, nome: string, role: UserRole, cargo: string) => Promise<void>;
  ativarUsuario: (targetUid: string) => Promise<void>;
  enterDemoMode: (role?: UserRole) => void;
  exitDemoMode: () => void;
  switchDemoRole: (role: UserRole) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [demoProfile, setDemoProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        setIsDemoMode(false);
        setDemoProfile(null);
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data() as UserProfile;
            setUserProfile(data);
          } else {
            // Primeiro acesso: provisiona perfil inicial
            const isAdminEmail = user.email === 'nevesvalnei@gmail.com';
            const initialRole: UserRole = isAdminEmail ? 'gestao' : 'responsavel_obra';
            // 7.1: Novos usuários entram como 'pendente', exceto o administrador inicial
            const initialStatus = isAdminEmail ? 'ativo' : 'pendente';

            const newProfile: UserProfile = {
              uid: user.uid,
              nome: user.displayName || user.email?.split('@')[0] || 'Usuário Construtora',
              email: user.email || '',
              role: initialRole,
              cargo: isAdminEmail ? 'Administrador Geral' : 'Engenheiro Residente',
              status: initialStatus,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };

            await setDoc(doc(db, 'users', user.uid), newProfile);

            // Garante documento em /admins/{uid} para o administrador inicial confiável
            if (isAdminEmail) {
              await setDoc(doc(db, 'admins', user.uid), {
                uid: user.uid,
                email: user.email,
                addedAt: new Date().toISOString(),
              });
            }

            setUserProfile(newProfile);
          }
        } catch (e) {
          console.error('Erro ao carregar perfil real do Firestore:', e);
          setUserProfile(null);
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const isInactive = userProfile !== null && userProfile.status === 'inativo';
  const isPending = userProfile !== null && userProfile.status === 'pendente';

  const loginWithEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      setIsDemoMode(false);
      setDemoProfile(null);
      const cred = await signInWithEmailAndPassword(auth, email, pass);
      setCurrentUser(cred.user);
    } finally {
      setLoading(false);
    }
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    nome: string,
    role: UserRole,
    cargo: string
  ) => {
    setLoading(true);
    try {
      setIsDemoMode(false);
      setDemoProfile(null);
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      const isAdminEmail = email.trim() === 'nevesvalnei@gmail.com';

      // 7.1: Novos cadastros entram com status 'pendente'
      const newProfile: UserProfile = {
        uid: cred.user.uid,
        nome: nome.trim(),
        email: email.trim(),
        role: isAdminEmail ? 'gestao' : role,
        cargo: cargo.trim() || 'Profissional da Obra',
        status: isAdminEmail ? 'ativo' : 'pendente',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'users', cred.user.uid), newProfile);

      if (isAdminEmail) {
        await setDoc(doc(db, 'admins', cred.user.uid), {
          uid: cred.user.uid,
          email: cred.user.email,
          addedAt: new Date().toISOString(),
        });
      }

      setUserProfile(newProfile);
    } finally {
      setLoading(false);
    }
  };

  const ativarUsuario = async (targetUid: string) => {
    if (!userProfile || (userProfile.role !== 'gestao' && userProfile.role !== 'administracao')) {
      throw new Error('Apenas Gestão ou Administração podem aprovar novos colaboradores.');
    }
    await updateDoc(doc(db, 'users', targetUid), {
      status: 'ativo',
      updatedAt: new Date().toISOString(),
    });
  };

  // Modo de Demonstração explícito e isolado
  const enterDemoMode = (role: UserRole = 'gestao') => {
    const demo = DEMO_USERS.find((u) => u.role === role) || DEMO_USERS[0];
    setDemoProfile(demo);
    setIsDemoMode(true);
  };

  const exitDemoMode = () => {
    setIsDemoMode(false);
    setDemoProfile(null);
  };

  const switchDemoRole = (role: UserRole) => {
    if (!isDemoMode) return;
    const demo = DEMO_USERS.find((u) => u.role === role) || DEMO_USERS[0];
    setDemoProfile(demo);
  };

  const logout = async () => {
    await firebaseSignOut(auth);
    setCurrentUser(null);
    setUserProfile(null);
    setIsDemoMode(false);
    setDemoProfile(null);
  };

  const activeProfile = isDemoMode ? demoProfile : userProfile;
  const activeRole = activeProfile?.role || null;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile: activeProfile,
        loading,
        activeRole,
        isInactive,
        isPending,
        isDemoMode,
        loginWithEmail,
        registerWithEmail,
        ativarUsuario,
        enterDemoMode,
        exitDemoMode,
        switchDemoRole,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
