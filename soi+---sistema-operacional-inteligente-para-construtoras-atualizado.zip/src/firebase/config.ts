import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase with the configured project
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
// CRITICAL: Must pass firebaseConfig.firestoreDatabaseId to bind to the allocated enterprise database
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase connection: client appears offline, using cached/local mode.');
    } else {
      console.info('Firebase connection handshake evaluated:', error);
    }
    return false;
  }
}
